'use strict';
const normalNextTask=nextTask;
nextTask=async function(){if(!current?.state.demo_fixture)return normalNextTask();await saveNotebook();update(await scoped('demo-next','POST',{}));if(current.state.report){$('#report-preview').scrollIntoView({behavior:'smooth',block:'start'});}else window.scrollTo({top:0,behavior:'smooth'});};
let normalDemoReportHandler=null;
const demoPreviousClarity=renderClarity;
renderClarity=function(){demoPreviousClarity();if(!current||!$('#demo-walkthrough-note'))return;const s=current.state,on=!!s.demo_fixture;$('#demo-walkthrough-note').classList.toggle('hidden',!on);if(!on){$('#authorship').closest('label').classList.remove('hidden');if(normalDemoReportHandler)$('#build-report').onclick=normalDemoReportHandler;return;}
 $('#demo-walkthrough-note').textContent=W('完整离线演示：内容、实验数值和示例理由均已预填，全部为虚构。勾选AI伙伴后可查看脚本反馈；也可直接点下一步。若尚未处理反馈，下一步会记录“示例：保留原稿”并继续，不代表你的真实判断。','Complete offline walkthrough: text, values and example reasons are prefilled and fictional. Select partners for scripted feedback or click Next. If feedback is pending, Next records an example decision to retain the draft; it does not represent your own judgement.');
 $('#next').classList.remove('hidden');$('#next').disabled=busy;$('#next').textContent=s.stage===4?(s.report?W('演示报告已完成','Demo report completed'):W('完成演示，查看示例报告','Finish demo and view sample report')):W('下一步（演示内容已填好）','Next (demo content prefilled)');
 if(s.stage===4){$('#report-tools').classList.remove('hidden');$('#authorship').closest('label').classList.add('hidden');$('#build-report').textContent=W('生成虚构示例报告','Generate fictional sample report');$('#build-report').onclick=()=>action(()=>nextTask());}
 if(s.pending_reflection){$('#reflection-pending')?.classList.add('hidden');}
};
const demoOpenAdoption=openAdoption;
openAdoption=function(decision){demoOpenAdoption(decision);if(!current?.state.demo_fixture||!adoptionEdit)return;const key=adoptionEdit.draftKey;let saved;try{saved=JSON.parse(localStorage.getItem(key)||'null');}catch{}
 if(!saved?.reason)$('#adoption-reason').value=decision==='reject'?W('示例理由：保留当前表述，待收集真实数据后再判断是否修改。','Example reason: retain the text until real measurements allow a decision.'):W('示例理由：采纳关于明确测量方法和证据边界的建议，补充说明，仍需真实实验检验。','Example reason: clarify measurements and evidence limits; real experiments are still needed.');
 if(decision!=='reject'&&!saved?.notebook){const el=document.querySelector('[data-adoption-field]');if(el)el.value+='\n\n'+W('演示补充：进一步明确操作或判断标准，记录可能的混杂因素；目前没有真实实验数据，不能作事实结论。','Demo addition: clarify operational criteria and possible confounds; without actual data, no factual conclusion follows.');}rememberAdoption();
};
window.addEventListener('DOMContentLoaded',()=>{normalDemoReportHandler=$('#build-report').onclick;const note=document.createElement('p');note.id='demo-walkthrough-note';note.className='notice hidden';$('#draft-panel').before(note);if(current)renderClarity();});

window.addEventListener('DOMContentLoaded',()=>{
 const originalLanguageChange=$('#language').onchange;
 $('#language').onchange=()=>{if(!current?.state.demo_fixture)return originalLanguageChange();const lang=$('#language').value;action(async()=>{await saveNotebook();const d=await scoped('demo-language','POST',{language:lang});I18N.set(lang);update(d);});};
 const migrate=setInterval(()=>{if(!current||busy)return;clearInterval(migrate);if(current.state.demo_fixture)action(async()=>update(await scoped('demo-language','POST',{language:I18N.language})));},200);
});
