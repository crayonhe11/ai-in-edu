'use strict';
let feedbackTracking=false,feedbackStop=null,feedbackJobId=null;
async function feedbackHTTP(path,method='GET',data,signal){const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),method==='GET'?6000:185000);const abort=()=>controller.abort();signal?.addEventListener('abort',abort,{once:true});try{const r=await fetch(API+'/api/sessions/'+cred.id+'/'+path,{method,headers:{Authorization:'Bearer '+cred.token,'Content-Type':'application/json'},body:data?JSON.stringify(data):undefined,signal:controller.signal});const d=await r.json();if(!r.ok)throw Error(d.error||W('反馈请求失败','Feedback request failed'));return d;}finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);}}
function showFeedbackProgress(p){const names={mentor:W('探究导师','Inquiry mentor'),skeptic:W('思辨质疑者','Critical questioner'),peer:W('协作同伴','AI peer')},elapsed=Math.max(0,Math.floor(Date.now()/1000-(p.started_at||Date.now()/1000)));
 $('#core-feedback-status').textContent=p.phase==='retrying'?W(`Kimi请求限流，正在等待重试（间隔${p.retry_seconds}秒）。已用${elapsed}秒，最多等待180秒。`,`Kimi rate limit: waiting ${p.retry_seconds}s before retry. Elapsed ${elapsed}s; limit 180s.`):p.phase==='review_started'?W(`所选角色回复已收到，正在复核。已用${elapsed}秒。`,`Selected replies received; reviewing. Elapsed ${elapsed}s.`):W(`正在获取反馈：已用${elapsed}秒，最多等待180秒。`,`Getting feedback: ${elapsed}s elapsed, limit 180s.`);
 let box=$('#feedback-progress-steps');if(!box){box=document.createElement('div');box.id='feedback-progress-steps';$('#core-feedback-status').after(box);}box.innerHTML=Object.entries(names).filter(([r])=>!p.selected_roles||p.selected_roles.includes(r)).map(([r,n])=>'<p><strong>'+n+'</strong> · '+(p.roles?.[r]==='received'?W('回复已收到，等待复核后展示','Reply received; awaiting review'):p.roles?.[r]==='running'?W('正在生成','Generating'):W('等待中','Waiting'))+'</p>').join('')+'<p>'+W('复核通过后，回复会显示在右侧。','Replies appear on the right after review passes.')+'</p>';
 $('#cancel-feedback').classList.remove('hidden');$('#cancel-feedback').disabled=false;$('#get-core-feedback').disabled=true;
}
async function followFeedback(jobId,startPromise,controller){
 let settled=false,result,failure;const started=Date.now();if(startPromise)startPromise.then(d=>{result=d;settled=true;},e=>{failure=e;settled=true;});
 while(true){
  if(controller.signal.aborted)throw Error(W('已请求取消本轮反馈，原稿已保留。正在发送的模型请求可能仍需片刻结束。','Cancellation requested; your draft is preserved. An in-flight model request may take a moment to end.'));
  if(settled){if(failure)throw failure;return result;}
  if(Date.now()-started>185000){controller.abort();await feedbackHTTP('feedback-cancel','POST',{job_id:jobId}).catch(()=>{});throw Error(W('本轮已超过180秒，请稍后重试。','Feedback exceeded 180 seconds. Retry later.'));}
  const p=await feedbackHTTP('feedback-progress');
  if(p.job_id===jobId){
   showFeedbackProgress(p);
   if(p.status==='failed')throw Error(p.error);
   if(p.status==='done')return await scoped();
  }else if(!startPromise&&p.status==='idle')throw Error(W('后台已重启，本轮任务已结束，请重新获取反馈。','Server restarted; request feedback again.'));
  await new Promise(resolve=>setTimeout(resolve,1000));
 }
}
async function runFeedback(existing){
 const status=$('#core-feedback-status');delete status.dataset.failure;feedbackTracking=true;feedbackStop=new AbortController();const controller=feedbackStop;let totalTimer,jobId;
 try{
  let promise;
  if(existing){jobId=existing.job_id;showFeedbackProgress(existing);}else{const roles=selectedFeedbackRoles();await saveNotebook();jobId=crypto.randomUUID();showFeedbackProgress({selected_roles:roles,roles:{},started_at:Date.now()/1000,phase:'starting'});promise=feedbackHTTP('chat','POST',{message:W('请针对我已提交的本步初稿提出具体改进问题。分别检查依据、证据边界和可以完善的地方，不替我重写核心内容。','Give specific feedback questions on my submitted draft: reasoning, evidence limits and improvements. Do not rewrite core work.'),language:I18N.language,roles,progress_id:jobId},controller.signal);}
  feedbackJobId=jobId;sessionStorage.setItem('inquiry-feedback:'+cred.id,jobId);totalTimer=setTimeout(()=>{controller.abort();feedbackHTTP('feedback-cancel','POST',{job_id:jobId}).catch(()=>{});},185000);
  const d=await followFeedback(jobId,promise,controller);update(d);if(current.state.pending_reflection)dismissReflection();$('#core-feedback-comparison').scrollIntoView({behavior:'smooth',block:'start'});
 }catch(e){const message=e.name==='AbortError'?W('等待已停止，原稿保留；请稍后重试。','Waiting stopped; your draft is preserved. Retry later.'):e.message;status.dataset.failure=message;status.dataset.draftId=(current.state.drafts||[]).filter(d=>d.node===nodeName(current.state.stage)).at(-1)?.id||'';status.textContent=message;throw Error(message);
 }finally{clearTimeout(totalTimer);if(sessionStorage.getItem('inquiry-feedback:'+cred.id)===jobId)sessionStorage.removeItem('inquiry-feedback:'+cred.id);$('#feedback-progress-steps')?.remove();$('#cancel-feedback').classList.add('hidden');feedbackTracking=false;feedbackStop=null;feedbackJobId=null;}
}
window.addEventListener('DOMContentLoaded',()=>{
 const cancel=document.createElement('button');cancel.id='cancel-feedback';cancel.type='button';cancel.className='quiet hidden';cancel.textContent=W('取消等待，保留初稿','Cancel waiting, keep draft');$('#core-feedback-status').after(cancel);
 cancel.onclick=()=>{sessionStorage.removeItem('inquiry-feedback:'+cred.id);const jobId=feedbackJobId;feedbackStop?.abort();if(jobId)feedbackHTTP('feedback-cancel','POST',{job_id:jobId}).catch(()=>{});};
 $('#get-core-feedback').onclick=()=>action(()=>runFeedback());
 // Reloading observes the existing request instead of sending another paid request.
 const restore=async()=>{if(!current||busy||feedbackTracking)return;const key='inquiry-feedback:'+cred.id,id=sessionStorage.getItem(key);if(!id)return;try{const p=await feedbackHTTP('feedback-progress');if(p.status==='running'&&p.job_id===id)action(()=>runFeedback(p));else sessionStorage.removeItem(key);}catch{sessionStorage.removeItem(key);}};
 const wait=setInterval(()=>{if(current&&!busy){clearInterval(wait);restore();}},500);
});
