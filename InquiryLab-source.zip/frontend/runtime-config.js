// Standalone static-server fallback. main.py overrides this with a same-origin API.
window.INQUIRY_API_BASE = 'http://127.0.0.1:8765';
