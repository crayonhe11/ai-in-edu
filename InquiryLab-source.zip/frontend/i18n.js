'use strict';
window.I18N=(()=>{
 const D={
 '科学探究工作室':'Science Inquiry Studio','可证伪条件':'Falsifiability condition','什么实际结果会让你修改或放弃假设？':'What result would make you revise or reject your hypothesis?','请用自己的话说明反例。':'Describe a counterexample in your own words.','AI使用声明':'AI use acknowledgement','说明哪些帮助来自AI，哪些内容由你完成及核查。':'Explain what help came from AI and what you authored and verified.','如未使用AI也请说明。':'State if you did not use AI.','科学探究 / 初中科学 / 自主探究':'Science inquiry / Secondary science / Your inquiry','写出自变量条件及单位。':'State the independent-variable conditions and units.','例如：不同光照时间与发芽率有什么关系？':'For example: how does light duration relate to germination rate?','你的探究旅程':'Your inquiry journey','学生主导 · AI 提供支架':'Student-led learning · AI scaffolding','每一个想法，都值得用证据检验。':'Every idea deserves to be tested with evidence.',
 '教师指导与系统说明 ↗':'Teacher guidance & system information ↗','科学探究 / 初中科学 / 纸直升机':'Science inquiry / Secondary science / Paper helicopter','连接中':'Connecting','导出记录':'Export notebook',
 '让问题，带你走得更远':'Let questions take you further','你提出想法、寻找证据。三位 AI 伙伴，陪你把思考再推进一步。':'You develop ideas and collect evidence. Three AI partners help you take the next step.',
 '本次探究':'This inquiry','纸直升机的翼长':'Does paper-helicopter wing length','会影响下落时间吗？':'affect its fall time?','从一个可测量的问题出发，用真实观察建立自己的解释。':'Start with a measurable question and build an explanation from real observations.',
 '约 12–15 岁':'Ages 12–15','变量控制':'Control of variables','证据与论证':'Evidence and reasoning','提出问题':'Question','提出假设':'Hypothesis','设计实验':'Plan','收集证据':'Evidence','论证反思':'Reflection',
 '记录由你书写':'You author the notebook','翼长条件':'Wing-length condition','例如：翼长 6 cm':'For example: wing length 6 cm','下落时间（秒）':'Fall time (seconds)','实际测量值':'Actual measurement','添加':'Add',
 '只录入实际测量。至少比较两个条件，每种条件测量三次。均值不代表因果证明。':'Enter actual measurements only. Compare at least two conditions, with three trials each. A mean is not proof of causation.',
 '上一步':'Back','保存记录':'Save notebook','保存并进入下一阶段 ↗':'Save & continue ↗','保存最终记录 ✓':'Save final notebook ✓','与你的探究伙伴讨论':'Discuss with your inquiry partners',
 '探究导师':'Inquiry mentor','思辨质疑者':'Critical questioner','协作同伴':'AI peer','如何提出好问题？':'How can I ask a good question?','帮我检查变量':'Check my variables',
 '发送给 AI 伙伴':'Message your AI partners','先说说你的想法，或描述你遇到的困难…':'Share your ideas or describe a difficulty…','先表达，再追问。你的思考是起点。':'Start with your own thinking, then ask questions.','发送想法 ↑':'Send idea ↑',
 '三个角色，一起推进思考':'Three roles to support your thinking','帮你明确问题与下一步':'Clarifies the question and next step','追问证据、变量与其他解释':'Questions evidence, variables and alternatives','拆解任务，邀请你作选择':'Breaks down tasks and invites your choice',
 '三位均为 AI 角色。后一个读取前一个的建议，共享你的探究记录。它们可能一起出错。':'All three are AI roles. Later roles read earlier advice and share your notebook. They can make the same mistake.',
 '实验前的约定':'Before the experiment','安全先行，证据真实':'Safety first, genuine evidence','只在地面站立高度释放轻质纸模型。场地与步骤先请教师检查。':'Release a light paper model only from standing height on the ground. Ask a teacher to check the site and procedure first.',
 '不攀高，不在楼梯旁实验。不要输入姓名、学校或联系方式。':'Do not climb or experiment near stairs. Do not enter names, schools or contact details.',
 '从一个好问题开始':'Begin with a good question','删除本次数据并重新开始':'Delete this session & restart','InquiryLab · INT7115 课程原型':'InquiryLab · INT7115 course prototype','学习成效尚待评估 · AI 建议需要核查':'Learning outcomes await evaluation · Verify AI advice',
 '教师指导与系统说明':'Teacher guidance & system information','关闭':'Close','本地演示中的当前会话指导面板，尚未实现独立教师登录与班级权限。不能当作正式学校管理平台。':'This local session panel has no separate teacher login or class permissions. It is not a production school management system.',
 '给本次探究的指导意见':'Guidance for this inquiry','例如：先检查释放高度是否保持一致。':'For example: check whether release height stays constant.','暂停本会话的 AI 对话，等待教师指导':'Pause AI dialogue while awaiting teacher guidance','保存指导':'Save guidance','角色协作轨迹':'Role coordination trace','运行状态':'System status',
 '后端 API 地址':'Backend API address','保存地址并重连':'Save address & reconnect','这里仅填写你控制的后端地址。Kimi Key 只填写 backend/.env，不在网页输入。切换地址会删除当前浏览器中的会话凭据，不会删除原服务器数据，请先导出或删除。':'Only enter a backend address you control. Put the Kimi key in backend/.env, never in the browser. Switching clears browser credentials, but does not delete server data. Export or delete your session first.',
 '探究问题':'Inquiry question','写出能够通过测量回答的问题。':'Write a question that measurements can answer.','例如：翼长变化与下落时间有什么关系？':'For example: how does wing length relate to fall time?',
 '我的假设':'My hypothesis','预测是待检验的想法，不是已经证明的结果。':'A prediction is an idea to test, not an established result.','如果……那么……':'If… then…','预测依据':'Reason for my prediction',
 '你为什么这样预测？哪些观察或已有知识支持它？':'Why do you predict this? What observations or prior knowledge support it?','写下你的初步解释。':'Write your initial explanation.',
 '自变量':'Independent variable','你准备主动改变的因素是什么？':'Which factor will you deliberately change?','写出翼长条件及单位。':'State the wing-length conditions and units.',
 '因变量':'Dependent variable','你将测量什么，使用什么单位？':'What will you measure, and in which units?','写出测量方法。':'Describe the measurement method.',
 '控制变量':'Controlled variables','为公平比较，哪些条件需要保持相同？':'Which conditions must stay the same for a fair comparison?','由你决定，并说明理由。':'Decide and explain your reasoning.',
 '实验步骤与安全':'Procedure and safety','写出可以重复执行的步骤，先请教师检查。':'Write repeatable steps and ask a teacher to review them first.','包括释放方式、计时、重复次数和安全安排。':'Include release method, timing, repeated trials and safety.',
 '我的主张':'My claim','结论由你形成，允许与最初预测不同。':'You form the conclusion. It may differ from your prediction.','根据实际观察，我认为……':'Based on actual observations, I think…',
 '我的证据':'My evidence','引用自己记录的数值、单位和重复测量。':'Cite your recorded values, units and repeated measurements.','哪些数据支持或挑战你的主张？':'Which data support or challenge your claim?',
 '证据如何支持解释':'How evidence supports my explanation','说明数据与主张之间的联系。':'Explain the link between the data and your claim.','同时考虑其他可能的解释。':'Consider other possible explanations.',
 '局限与下一步':'Limitations and next steps','什么还不能确定？下一次如何改进？':'What remains uncertain? What could improve next time?','至少写出一个限制与改进方向。':'State at least one limitation and an improvement.',
 '把好奇心转化为一个可测量的问题。':'Turn your curiosity into a measurable question.','先提出预测，再想想怎样的结果会挑战它。':'Make a prediction, then consider what result would challenge it.',
 '一次主要改变一个因素，其他重要条件保持一致。':'Change one main factor while holding other important conditions constant.','实际实验先经教师确认。这里只整理你录入的测量值。':'Ask a teacher to approve the experiment first. This page only organises the values you enter.',
 '用主张、证据与解释整理自己的结论，同时保留不确定性。':'Organise your conclusion using a claim, evidence and reasoning, while acknowledging uncertainty.',
 '阶段检查只确认记录完整，不代表科学正确或教师审批。':'Stage checks confirm completeness, not scientific correctness or teacher approval.',
 '我的想法':'My idea','脚本演示':'Scripted demo','Kimi 实时':'Live Kimi','教学边界提示':'Learning boundary reminder','学生输入':'Student input',
 '先在探究记录中写下你的想法，':'First write your ideas in the notebook,','再邀请 AI 伙伴一起追问。':'then invite the AI partners to ask questions.',
 '操作':'Action','删除':'Delete','尚无测量数据，系统不会自动补齐或生成实验结果。':'No measurements yet. The system will not fill in or invent experimental results.',
 '后续角色已接收此前建议':'Later roles received the earlier advice','规则提示，本轮未调用模型':'Rule-based reminder, no model call this turn','尚无协作调用记录':'No coordination trace yet',
 'Kimi 实时模式':'Live Kimi mode','离线脚本演示':'Offline scripted demo',
 '实时模式：发送内容和探究记录会传至 Kimi。AI 可能出错，实验与结论需要学生和教师核查。':'Live mode: messages and the inquiry notebook are sent to Kimi. AI can be wrong. Students and teachers must review experiments and conclusions.',
 '演示模式：三个角色使用按阶段编写的脚本，未调用 Kimi，不能用于判断模型能力或学习效果。填入后端 Key 并切换 APP_MODE=live 后可使用实时模式。':'Demo mode: the three roles use stage-specific scripts, with no Kimi calls. This cannot evaluate model ability or learning outcomes. Add the backend key and set APP_MODE=live for live mode.',
 '请先写下你的想法':'Please write your idea first','伙伴正在依次思考…':'The partners are responding in turn…','删除本次后端数据和浏览器凭据？此操作无法恢复，请先导出。':'Delete this session and browser credentials? This cannot be undone. Export first.',
 '后端地址须使用 http 或 https':'Use an http or https backend address','怎样把我的想法变成可测量的问题？':'How can I turn my idea into a measurable question?','请检查我记录中的控制变量，有哪些仍需澄清？':'Please check my controlled variables. What needs clarification?',
 '请先完成本阶段记录':'Complete this stage’s notebook first','至少两种翼长条件，每种至少三次测量':'At least two wing-length conditions, with three measurements each',
 '会话不存在或访问凭据无效':'Session not found or invalid access token','教师已暂停 AI 对话，可继续修改探究记录':'AI dialogue is paused. You can still edit the notebook.',
 '本次探究已达到30轮上限，请先导出记录':'This inquiry has reached 30 turns. Export your notebook first.','尚未配置 KIMI_API_KEY。请在后端 .env 中填写并重启后端':'KIMI_API_KEY is not configured. Set it in backend/.env and restart main.py.',
 'Kimi Key 无效，请检查后端 .env':'Invalid Kimi key. Check backend/.env.','Kimi 账户无访问权限':'Kimi account access denied.','Kimi 限流或额度不足，请稍后重试':'Kimi rate limit or quota reached. Please retry later.',
 'Kimi 请求参数或模型名不被接受，请核对配置':'Kimi rejected the parameters or model name. Check the configuration.','Kimi 服务暂时不可用':'Kimi is temporarily unavailable.','Kimi 连接失败或超时，请检查网络后重试':'Kimi connection failed or timed out. Check your network and retry.',
 'Kimi 返回格式异常，请重试':'Unexpected Kimi response format. Please retry.','Kimi 返回空内容，请重试':'Kimi returned empty content. Please retry.','本会话正在处理请求，请稍后重试':'This session is busy. Please retry later.',
 '消息须为1至2000字':'Messages must contain 1–2000 characters.','下落时间须大于0且不超过120秒':'Fall time must be greater than zero and no more than 120 seconds.','请填写有效条件标签，最多40字':'Enter a condition label of up to 40 characters.','最多60条测量记录':'At most 60 measurements are allowed.',
 '创建会话过于频繁，请稍后重试':'Too many new sessions. Please retry later.','接口不存在或方法不支持':'API endpoint or method not supported.','接口不存在':'API endpoint not found.','服务器处理失败，数据未提交，请重试':'Server error. The data were not committed. Please retry.',
 '不允许的来源':'Origin not allowed.','探':'M','问':'Q','伴':'P','我':'Me','导师':'Mentor','质疑':'Questioner','同伴':'Peer'
 };
 let language=localStorage.getItem('inquiry-language')||'zh';if(!['zh','en','bi'].includes(language))language='zh';
 const original=new WeakMap(),attrs=new WeakMap();
 function english(source){
  const lead=source.match(/^\s*/)[0],tail=source.match(/\s*$/)[0],s=source.trim();if(!s)return source;
  if(D[s])return lead+D[s]+tail;
  if(/^\d+ \/ 30 轮$/.test(s))return s.replace('轮','turns');
  if(/^当前阶段 /.test(s))return s.replace('当前阶段','Current stage').replace(/提出问题|提出假设|设计实验|收集证据|论证反思/g,x=>D[x]);
  if(/^已保存 /.test(s))return s.replace('已保存','Saved');
  if(/^范围：/.test(s))return s.replace('范围：','Range: ').replace('秒','s');
  if(/^[\d.]+ 秒 \/ n=/.test(s))return s.replace('秒','s');
  return source;
 }
 function text(source){const parts=source.split(' / ');if(parts.length===2&&/[\u4e00-\u9fff]/.test(parts[0])&&/[A-Za-z]/.test(parts[1])&&!D[source.trim()])return language==='zh'?parts[0]:language==='en'?parts[1]:source;if(language==='zh')return source;const en=english(source);return language==='bi'&&en.trim()!==source.trim()?source.trim()+' / '+en.trim():en;}
 function apply(){
  document.documentElement.lang=language==='en'?'en':'zh-CN';document.documentElement.dataset.language=language;
  const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;
  while(n=walker.nextNode()){
   if(n.parentElement.closest('script,style,textarea,option,.message p,[data-user-content],#error'))continue;
   const old=original.get(n),src=old&&n.nodeValue===old.out?old.src:n.nodeValue,out=(language==='bi'&&n.parentElement.closest('.avatar'))?src:text(src);original.set(n,{src,out});if(n.nodeValue!==out)n.nodeValue=out;
  }
  document.querySelectorAll('[placeholder],[aria-label]').forEach(el=>{
   let cache=attrs.get(el)||{};for(const key of ['placeholder','aria-label']){if(!el.hasAttribute(key))continue;const cur=el.getAttribute(key),old=cache[key],src=old&&cur===old.out?old.src:cur,out=text(src);cache[key]={src,out};if(cur!==out)el.setAttribute(key,out);}attrs.set(el,cache);
  });
  document.title=language==='en'?'InquiryLab · Science Inquiry Studio':'InquiryLab · 科学探究工作室';
 }
 const observer=new MutationObserver(()=>apply());observer.observe(document.body,{childList:true,subtree:true,characterData:true});
 apply();
 return {get language(){return language;},text,apply,set(lang){language=lang;localStorage.setItem('inquiry-language',lang);apply();}};
})();
