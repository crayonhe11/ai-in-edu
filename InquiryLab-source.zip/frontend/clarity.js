'use strict';
const TASKS=[
 {title:['先写下你想研究的问题','Write the question you want to investigate'],brief:['写一个可以通过观察或测量回答的问题。完成后，进入下一步提出猜想。','Write a question you can answer through observation or measurement, then continue to your prediction.'],goal:['一句能通过实验回答的问题','One question an experiment can answer'],tip:['想一想：你准备改变什么，又观察什么？','What would you change, and what would you observe?'],nav:['提出问题','Ask a question'],next:['下一步：写下猜想','Next: make a prediction']},
 {title:['写下你的猜想，以及理由','Write your prediction and explain why'],brief:['先自己预测结果，再说明依据，以及什么结果会让你改变想法。','Make your own prediction, explain your reasoning and describe a result that would change your mind.'],goal:['预测、理由和反例条件','A prediction, a reason and a possible counterexample'],tip:['猜错也没关系。你的猜想需要能被实验检验。','It is fine if your prediction is wrong. It needs to be testable.'],nav:['提出猜想','Make a prediction'],next:['下一步：设计实验','Next: plan the experiment']},
 {title:['设计一个公平、安全的实验','Plan a fair and safe experiment'],brief:['写清改变什么、测量什么、保持什么相同，再写操作步骤。实际实验前请教师检查。','State what you change, measure and keep constant. Write the steps and ask a teacher to review them before experimenting.'],goal:['变量设置和可重复的操作步骤','Variables and repeatable steps'],tip:['一次主要改变一个因素。AI检查和仿真都是辅助工具。','Change one main factor. AI review and simulation are optional support.'],nav:['设计实验','Plan an experiment'],next:['下一步：记录真实数据','Next: record real data']},
 {title:['把你实际测到的数据记下来','Record what you actually measured'],brief:['先确认数据来自真实实验，再逐条填写，或选择上传CSV。至少比较两个条件，每种测量三次。','Confirm the data come from a real experiment, then enter values or upload a CSV. Use at least two conditions with three trials each.'],goal:['至少两个条件，每种三次真实测量','At least two conditions with three real measurements each'],tip:['保留异常值并记录可能的操作误差。不要使用仿真结果。','Keep unusual values and note possible measurement errors. Do not use simulated results.'],nav:['记录数据','Record data'],next:['下一步：解释与报告','Next: explain your findings']},
 {title:['用证据解释结果，完成报告','Explain your results and finish the report'],brief:['用自己的话写出主张、证据、解释和局限，声明AI使用，再组装并导出报告。','Write your claim, evidence, reasoning and limitations. Acknowledge AI assistance, then assemble and export your report.'],goal:['由你撰写、能追溯证据的报告','Your own report with traceable evidence'],tip:['结论可以与猜想不同，也可以说明证据暂时不足。','Your conclusion may differ from your prediction, or the evidence may be insufficient.'],nav:['解释与报告','Explain and report'],next:['保存本步内容','Save this step']}
];
let lastTaskStage=-1;
function wrapDisclosure(element,zh,en,id){if(!element||element.parentElement.id===id)return;const d=document.createElement('details');d.id=id;d.className='optional-tool';const sum=document.createElement('summary');sum.textContent=zh+' / '+en;element.before(d);d.append(sum,element);}
function completionItems(){
 if(!current)return[];const s=current.state;
 if(s.stage===3){const stats=current.statistics;return [
  {label:W('至少两个实验条件','At least two conditions'),done:stats.length>=2},
  {label:W('每个条件至少三次测量','At least three measurements per condition'),done:stats.length>=2&&stats.every(x=>x.n>=3)},
  {label:W('只使用真实测量','Use actual measurements only'),done:s.observations.length>0&&s.observations.every(r=>r.source!=='simulation')}
 ];}
 const draft=localFields();return stageFields[s.stage].map(k=>({label:I18N.text(fields[k][0]),done:!!(draft[k]??s.notebook[k]??'').trim(),field:k}));
}
function renderChecklist(){
 if(!current)return;const items=completionItems(),done=items.filter(x=>x.done).length;
 $('#task-checklist').innerHTML=items.map(x=>`<li class="${x.done?'checked':''}"><span aria-hidden="true">${x.done?'✓':'○'}</span>${esc(x.label)}</li>`).join('');
 $('#task-completion').textContent=W(`已填写 ${done} / ${items.length} 项`,`Completed ${done} / ${items.length}`);
 $('#task-completion').classList.toggle('all-done',done===items.length);
 $('#step-ready').textContent=done===items.length?W('本步记录已齐，可以继续。','This step is complete. You can continue.'):W(`还需完成 ${items.length-done} 项。完成清单会随填写更新。`,`${items.length-done} items remain. The checklist updates as you write.`);
}
function renderClarity(){
 if(!current||!$('#task-title'))return;const s=current.state,k=s.stage,t=TASKS[k];
 $('#task-title').textContent=W(...t.title);$('#task-description').textContent=W(...t.brief);$('#step-number').textContent=W(`第 ${k+1} 步，共 5 步`,`Step ${k+1} of 5`);$('#goal-output').textContent=W(...t.goal);$('#context-tip').textContent=W(...t.tip);
 $('.compact-topic').classList.toggle('hidden',k===0&&!s.notebook.question.trim());
 $('#task-project').textContent=s.topic.title;$('#question-choices').classList.toggle('hidden',k!==0);$('#unit-summary')?.classList.toggle('hidden',k!==0);if($('#unit-summary'))$('#unit-summary').textContent=W('后续测量单位：'+s.topic.unit+'。不适用时，展开下方设置调整。','Measurement unit: '+s.topic.unit+'. Expand the settings below if you need a different unit.');$('#project-settings')?.classList.toggle('hidden',k!==0);
 $('#notebook-eyebrow').textContent=W('在这里完成本步','Complete this step here');$('#stage-title').textContent=W(...t.nav);$('#stage-help').textContent=W(...t.brief);
 $('#next').textContent=W(...t.next);$('#next').classList.toggle('hidden',k===4);$('#save').textContent=W('保存草稿','Save draft');
 $('#stages').innerHTML=TASKS.map((v,i)=>`<button type="button" class="stage-item ${i===k?'active':i<k?'done':''}" ${i===k?'aria-current="step"':''} data-review-stage="${i}" ${i>k?'disabled':''}><span class="stage-num">${i<k?'✓':i+1}</span><span class="stage-copy"><strong>${esc(W(...v.nav))}</strong><small>${i===k?W('正在进行','In progress'):i<k?W('查看已完成步骤','Review previous step'):W('接下来','Coming up')}</small></span></button>`).join('');
 if(s.pending_reflection&&$('#assistant-dialog').open)$('#assistant-dialog').close();
 $('#help-subtitle').textContent=W('需要时再问。AI会追问，不会替你完成。','Ask when you need help. AI asks questions rather than completing your work.');
 $('#ask-help').textContent=W('卡住了？问 AI 伙伴','Stuck? Ask your AI partners');$('#ask-help').disabled=!!s.pending_reflection||s.teacher.paused;
 $('#help-paused').textContent=s.teacher.paused?W('教师已暂停AI，可继续填写记录。','AI is paused by your teacher. You can still edit your notebook.'):'';
 $('#report-tools h3').textContent=W('最后：组装并导出你的报告','Finally: assemble and export your report');$('#build-report').textContent=W('组装我的报告','Assemble my report');$('#download-report').textContent=W('下载报告','Download report');$('#download-report').disabled=!s.report;
 const decl=$('#declared-real');if(decl){$('#add-row').disabled=!!s.pending_reflection;}
 // Keep optional panels closed when entering another step, and leave them alone while typing.
 if(lastTaskStage!==k){for(const id of ['project-settings','plan-simulation','csv-options','report-reference','report-structure','system-notice']){const el=$('#'+id);if(el)el.open=false;}lastTaskStage=k;}
 renderChecklist();I18N.apply();
}
function revealErrorField(){const missing=completionItems().find(x=>!x.done);if(missing?.field){const field=document.querySelector(`#notebook-form textarea[name="${missing.field}"]`);field?.setAttribute('aria-invalid','true');field?.focus();}}
async function nextTask(){
 const missing=completionItems().filter(x=>!x.done);
 if(missing.length){$('#step-inline-error').textContent=W('请先完成：','First complete: ')+missing.map(x=>x.label).join('、');$('#step-inline-error').classList.remove('hidden');revealErrorField();return;}
 $('#step-inline-error').classList.add('hidden');await saveNotebook();
 if(current.state.stage===0&&current.state.notebook.question!==current.state.topic.title&&!current.state.observations.length&&!current.state.simulations.length){
  const q=current.state.notebook.question;
  current=await scoped('topic','POST',{title:q,unit:$('#project-unit').value||current.state.topic.unit,preset:q===$('#project-title').value?($('#project-preset').value||'custom'):'custom'});
 }
 if(current.state.stage<4)current=await scoped('advance','POST',{});render();window.scrollTo({top:0,behavior:'smooth'});
}
function simplifyTeacher(){
 const root=$('#teacher-detail');if(!root)return;const guidance=$('#dashboard-note')?.closest('label');if(guidance){const h=document.createElement('h4');h.textContent=W('给学生的指导','Guidance for this student');guidance.before(h);}
 for(const heading of [...root.querySelectorAll(':scope > h4')]){
  const d=document.createElement('details'),sum=document.createElement('summary');d.className='teacher-section';d.open=/指导|Guidance/.test(heading.textContent);sum.textContent=heading.textContent;heading.before(d);d.append(sum);let next=heading.nextSibling;heading.remove();
  while(next&&!(next.nodeType===1&&(next.matches('h4')||next.id==='teacher-export'))){const n=next.nextSibling;d.append(next);next=n;}
 }
}
function initClarity(){
 const primary=$('.primary'),notebook=$('.notebook'),actions=$('.notebook-actions');
 // Related tools sit beside the form they support, before the one next-step action.
 notebook.insertBefore($('#plan-tools'),actions);notebook.insertBefore($('#report-tools'),actions);
 wrapDisclosure($('#project-config'),'可选：调整主题或测量单位','Optional: adjust topic or measurement unit','project-settings');$('#notebook-form').after($('#project-settings'));const unitNote=document.createElement('p');unitNote.id='unit-summary';unitNote.className='micro';$('#notebook-form').after(unitNote);
 const simulation=document.createElement('div');simulation.id='simulation-controls';let move=$('#plan-tools h4');while(move){const next=move.nextSibling;simulation.append(move);move=next;}$('#plan-tools').append(simulation);wrapDisclosure(simulation,'可选：用仿真查看噪声影响','Optional: explore measurement noise','plan-simulation');
 const declaration=$('#declared-real').closest('label');$('#measurements').insertBefore(declaration,$('#entry-options'));
 const csv=$('#csv-file').closest('section');wrapDisclosure(csv,'已有表格？上传 CSV','Have a table? Upload a CSV','csv-options');
 wrapDisclosure($('#report-source-preview'),'检查报告结构与已填写内容','Review the report structure','report-structure');
 const refs=document.createElement('div');refs.id='report-reference-fields';let start=$('#source-list').closest('details');while(start&&!start.classList?.contains('check')){const next=start.nextSibling;refs.append(start);start=next;}$('#report-tools').insertBefore(refs,$('#authorship').closest('label'));wrapDisclosure(refs,'可选：引用了具体AI内容？补充改写与来源','Optional: rewrite and cite an AI excerpt','report-reference');
 $('#assistant-dialog').append($('.conversation'));
 $('#ask-help').onclick=()=>{if(current?.state.pending_reflection)return;$('#assistant-dialog').showModal();$('#message').focus();};$('#assistant-close').onclick=()=>$('#assistant-dialog').close();
 $('#notebook-form').addEventListener('input',e=>{e.target.removeAttribute('aria-invalid');$('#step-inline-error').classList.add('hidden');renderChecklist();});
 $('#declared-real').addEventListener('change',()=>{$('#entry-options').classList.toggle('needs-confirmation',!$('#declared-real').checked);});
 $('#next').onclick=()=>action(nextTask);
 $('#back').onclick=()=>action(async()=>{await saveNotebook();current=await scoped('back','POST',{});render();window.scrollTo({top:0,behavior:'smooth'});});
 $('#stages').onclick=e=>{const b=e.target.closest('[data-review-stage]');if(!b||b.disabled)return;const target=Number(b.dataset.reviewStage);if(target>=current.state.stage)return;action(async()=>{await saveNotebook();while(current.state.stage>target)current=await scoped('back','POST',{});render();window.scrollTo({top:0,behavior:'smooth'});});};
 for(const b of document.querySelectorAll('[data-question-choice]'))b.onclick=()=>{const presets={helicopter:[W('纸直升机的翼长会影响下落时间吗？','Does paper-helicopter wing length affect fall time?'),I18N.language==='en'?'s':'秒'],mung:[W('光照时间如何影响绿豆发芽率？','How does light duration affect mung-bean germination rate?'),'%']};const v=presets[b.dataset.questionChoice];if(v){document.querySelector('textarea[name="question"]').value=v[0];$('#project-preset').value=b.dataset.questionChoice;$('#project-title').value=v[0];$('#project-unit').value=v[1];}else{document.querySelector('textarea[name="question"]').focus();$('#project-preset').value='custom';$('#project-settings').open=true;}renderChecklist();};
 const oldLanguage=$('#language').onchange;$('#language').onchange=()=>{oldLanguage();renderClarity();};
 // These panels contain supporting explanations, so only the one needed is expanded.
 if(current)renderClarity();
}
const baseRender=render;render=function(){baseRender();renderClarity();};
const baseTeacherDetail=loadTeacherDetail;loadTeacherDetail=async function(sid){await baseTeacherDetail(sid);simplifyTeacher();};
window.addEventListener('DOMContentLoaded',initClarity);
