#!/usr/bin/env python3
"""InquiryLab application entry point: python3 main.py."""
import argparse,http.client,json,os,shutil,sys,threading,webbrowser,signal,ipaddress
from urllib.parse import urlsplit
from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'backend'))

def main(argv=None):
 if sys.version_info < (3,10):raise SystemExit('需要 Python 3.10+ / Python 3.10+ required')
 signal.signal(signal.SIGTERM,lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
 parser=argparse.ArgumentParser(description='Start InquiryLab / 启动科学探究工作室')
 parser.add_argument('--host',default=os.getenv('HOST','127.0.0.1'),help='Listen address; use 0.0.0.0 for cloud hosting')
 parser.add_argument('--port',type=int,default=int(os.getenv('PORT','5173')),help='Preferred browser port; automatically selects a free port if occupied')
 parser.add_argument('--no-browser',action='store_true',help='Do not open the browser automatically')
 args=parser.parse_args(argv)
 if not 0<=args.port<=65535:parser.error('Port must be between 0 and 65535')
 cloud_demo=os.getenv('PUBLIC_DEMO','0')=='1'
 if cloud_demo:os.environ['APP_MODE']='demo'
 if not (ROOT/'backend/.env').exists() and (ROOT/'backend/.env.example').exists() and not cloud_demo:shutil.copyfile(ROOT/'backend/.env.example',ROOT/'backend/.env')
 import server as backend
 Path(backend.DB).parent.mkdir(parents=True,exist_ok=True)
 for public_url in (os.getenv('PUBLIC_URL',''),os.getenv('RENDER_EXTERNAL_URL','')):
  if public_url:
   parsed=urlsplit(public_url)
   if parsed.scheme not in ('http','https') or not parsed.netloc or parsed.path not in ('','/'):raise SystemExit('PUBLIC_URL must be an http(s) origin without a path')
   backend.ORIGINS.add(parsed.scheme+'://'+parsed.netloc)
 if cloud_demo and not os.getenv('TEACHER_PASSWORD'):raise SystemExit('Set TEACHER_PASSWORD in the hosting dashboard before starting the public demo')
 backend.teacher_auth.ensure_key()
 print('教师口令文件 / Teacher access code: backend/.teacher_access (or TEACHER_PASSWORD in .env)',flush=True)
 if backend.MODE not in ('demo','live'):raise SystemExit('APP_MODE must be demo or live / 运行模式须为 demo 或 live')
 api=ThreadingHTTPServer(('127.0.0.1',0),backend.Handler)
 backend_thread=threading.Thread(target=api.serve_forever,daemon=True);backend_thread.start()
 class Gateway(SimpleHTTPRequestHandler):
  def __init__(self,*a,**kw):super().__init__(*a,directory=str(ROOT/'frontend'),**kw)
  def log_message(self,*a):pass
  def end_headers(self):
   self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');super().end_headers()
  def proxy(self):
   conn=None
   try:
    length=int(self.headers.get('Content-Length','0'))
    if length<0 or length>(50*1024*1024 if '/attachments' in self.path.split('?')[0] else 65536):self.send_error(413);return
    body=self.rfile.read(length) if length else None
    headers={k:self.headers[k] for k in ('Content-Type','Authorization','Origin') if self.headers.get(k)}
    client_ip=self.client_address[0]
    if os.getenv('TRUST_PROXY')=='1' and self.headers.get('X-Forwarded-For'):
     try:client_ip=str(ipaddress.ip_address(self.headers['X-Forwarded-For'].split(',')[-1].strip()))
     except ValueError:pass
    headers['X-Inquiry-Client-IP']=client_ip
    conn=http.client.HTTPConnection('127.0.0.1',api.server_port,timeout=max(160,4*(float(os.getenv('KIMI_TIMEOUT','45'))+120)+30))
    conn.request(self.command,self.path,body=body,headers=headers);response=conn.getresponse();data=response.read()
    self.send_response(response.status);self.send_header('Content-Type',response.getheader('Content-Type','application/json; charset=utf-8'));self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
   except (BrokenPipeError,ConnectionResetError):return # Browser refreshed or cancelled; no second response.
   except (OSError,ValueError,http.client.HTTPException):
    data=json.dumps({'error':'本地 API 连接失败，请重启 main.py / Local API unavailable. Restart main.py.'}).encode();self.send_response(502);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
   finally:
    if conn:conn.close()
  def do_GET(self):
   if self.path.split('?',1)[0].startswith('/api/'):return self.proxy()
   if self.path.split('?',1)[0]=='/runtime-config.js':
    data=b'window.INQUIRY_API_BASE=location.origin;';self.send_response(200);self.send_header('Content-Type','text/javascript');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
   super().do_GET()
  def do_POST(self):self.proxy()
  def do_PATCH(self):self.proxy()
  def do_DELETE(self):self.proxy()
  def do_OPTIONS(self):self.proxy()
 try:
  try:front=ThreadingHTTPServer((args.host,args.port),Gateway)
  except OSError:
   if args.host not in ('127.0.0.1','localhost'):raise
   print(f'端口 {args.port} 已占用，自动选择空闲端口 / Preferred port busy, selecting a free port.',flush=True)
   front=ThreadingHTTPServer((args.host,0),Gateway)
  url=f'http://127.0.0.1:{front.server_port}'
  backend.ORIGINS.update({url,f'http://localhost:{front.server_port}'})
  print('\nInquiryLab 已启动 / Ready\n'+url+'\n模式 / Mode: '+backend.MODE+'\n按 Ctrl+C 停止 / Press Ctrl+C to stop\n',flush=True)
  if not args.no_browser and args.host in ('127.0.0.1','localhost'):threading.Timer(.4,lambda:webbrowser.open(url)).start()
  try:front.serve_forever()
  except KeyboardInterrupt:print('\n已停止 / Stopped',flush=True)
  finally:front.server_close()
 finally:api.shutdown();api.server_close()

if __name__=='__main__':main()
