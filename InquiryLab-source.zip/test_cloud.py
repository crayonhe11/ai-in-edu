import json,os,subprocess,sys,tempfile,time,unittest,socket
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from pathlib import Path
class CloudDemo(unittest.TestCase):
 def test_public_demo(self):
  with tempfile.TemporaryDirectory() as temp,socket.socket() as sock:
   sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
   env={**os.environ,'PUBLIC_DEMO':'1','APP_MODE':'live','KIMI_API_KEY':'test-key-unused','TEACHER_PASSWORD':'cloud-test-password','DB_PATH':temp+'/nested/data.sqlite3','PORT':str(port),'HOST':'0.0.0.0','PUBLIC_URL':'https://example-demo.onrender.com'}
   proc=subprocess.Popen([sys.executable,str(Path(__file__).parent/'main.py'),'--no-browser'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE);base='http://127.0.0.1:'+str(port)
   def api(path,body=None,token=None):
    req=Request(base+'/api/'+path,data=json.dumps(body).encode() if body is not None else None,headers={'Content-Type':'application/json','Origin':env['PUBLIC_URL'],**({'Authorization':'Bearer '+token} if token else {})})
    with urlopen(req,timeout=5) as r:return json.load(r)
   try:
    for _ in range(100):
     try:h=api('health');break
     except OSError:time.sleep(.05)
    else:self.fail('Cloud launcher failed')
    self.assertTrue(h['public_demo']);self.assertEqual(h['mode'],'demo');self.assertFalse(h['configured'])
    session=api('sessions',{'language':'en'});s=session['state'];self.assertTrue(s['demo_fixture']);self.assertTrue(all(s['notebook'].values()));self.assertNotRegex(s['notebook']['procedure'],r'[\u4e00-\u9fff]');sid,token=session['id'],session['token']
    for _ in range(2):api('sessions/'+sid+'/demo-next',{},token)
    d=api('sessions/'+sid+'/chat',{'roles':['peer'],'message':'Please check my plan.','language':'en'},token)
    self.assertEqual(d['state']['audit'][-1]['api_calls'],0);self.assertEqual(d['state']['messages'][-1]['mode'],'demo')
    req=Request(base+'/api/sessions',data=b'{}',headers={'Content-Type':'application/json','Origin':'https://untrusted.invalid'})
    with self.assertRaises(HTTPError) as e:urlopen(req)
    self.assertEqual(e.exception.code,403);self.assertIn('token',api('teacher/login',{'password':env['TEACHER_PASSWORD']}))
    for path in ('/.env','/backend/.teacher_access','/backend/inquiry.sqlite3'):
     with self.assertRaises(HTTPError) as e:urlopen(base+path)
     self.assertEqual(e.exception.code,404)
   finally:
    proc.terminate()
    try:proc.communicate(timeout=5)
    except subprocess.TimeoutExpired:proc.kill();proc.communicate()
if __name__=='__main__':unittest.main()
