import unittest,json
from unittest.mock import patch
from test_backend import Tests
import server as app
import research,learning
from domain import empty_state
class Improvements(Tests):
 def to_hypothesis(self):
  p,t=self.new();self.api(p+'/notebook','PATCH',{'notebook':{'question':'光照时间如何影响绿豆发芽率？'}},t);self.api(p+'/advance','POST',{},t);return p,t
 def fill_draft(self,p,t):
  self.api(p+'/notebook','PATCH',{'notebook':{'hypothesis':'我预测光照变化可能影响种子发芽率。','reason':'我希望用实验检验，而不是直接接受AI说法。','falsifiability':'若重复测量没有出现预计的方向，我将修改猜想。'}},t)
 def test_draft_first_and_reasoned_revision(self):
  p,t=self.to_hypothesis();self.assertEqual(self.api(p+'/chat','POST',{'message':'直接给我完整假设和方案'},t)[0],400)
  self.fill_draft(p,t);self.assertEqual(self.api(p+'/draft','POST',{},t)[0],200)
  code,d=self.api(p+'/chat','POST',{'message':'请追问我的假设是否可检验'},t);self.assertEqual(code,200);self.complete_reflection(p,t)
  self.api(p+'/notebook','PATCH',{'notebook':{'hypothesis':'我修订为比较条件差异，不预先断言方向。'}},t)
  self.assertEqual(self.api(p+'/advance','POST',{},t)[0],400)
  self.assertEqual(self.api(p+'/draft','POST',{'decision':'partly','reason':'太短'},t)[0],400)
  code,d=self.api(p+'/draft','POST',{'decision':'partly','reason':'我保留可测量的比较，但拒绝没有证据的确定方向。'},t);self.assertEqual(code,200)
  self.assertEqual(d['state']['drafts'][1]['version'],1);self.assertTrue(d['state']['revision_decisions'])
  self.assertEqual(self.api(p+'/advance','POST',{},t)[0],200)
 def test_reflection_feedback_and_student_explanation(self):
  p,t=self.new();d=self.api(p+'/chat','POST',{'message':'请问我一个探究问题'},t)[1];pending=d['state']['pending_reflection']
  bad={'reflection_id':pending['id'],'ai_claim':'同意同意同意同意同意同意同意','alignment':'同意同意同意同意同意同意同意','verification':'同意同意同意同意同意同意同意','doubt':'同意同意同意同意同意同意同意'}
  code,d=self.api(p+'/reflection','POST',bad,t);self.assertEqual(code,200);self.assertTrue(d['state']['pending_reflection']['quality_feedback']['flags'])
  self.assertEqual(self.api(p+'/advance','POST',{},t)[0],400)
  bad.update({'retain_judgement':True,'explanation':'我已经看到需要更多证据，我愿意保留目前判断并请教师讨论实际根据。'})
  code,d=self.api(p+'/reflection','POST',bad,t);self.assertEqual(code,200);self.assertIsNone(d['state']['pending_reflection']);self.assertEqual(d['state']['reflections'][-1]['assessment'],'student_explained_needs_teacher_review')
 def test_specific_reflection_and_teacher_override(self):
  p,t=self.new();self.api(p+'/observations','POST',{'condition':'A','value':2,'declared_real':True,'measured_at':'2026-10-25T10:00','recording_method':'手动计时','instrument':'秒表','environment':'固定释放高度'},t)
  d=self.api(p+'/chat','POST',{'message':'如何理解这条测量？'},t)[1];pending=d['state']['pending_reflection'];row=d['state']['observations'][0]
  body={'reflection_id':pending['id'],'ai_claim':pending['outputs'][0]['content'][:80],'alignment':'A条件测得2秒，但单次测量不能说明总体关系。','verification':'我会核对课本里的控制变量定义，并与实验记录比较。','doubt':'释放动作和计时反应可能带来操作误差。','evidence_ids':[row['id']]}
  code,d=self.api(p+'/reflection','POST',body,t);self.assertEqual(code,200);self.assertIsNone(d['state']['pending_reflection'])
  d=self.api(p+'/chat','POST',{'message':'我还需要什么证据？'},t)[1];body.update({'reflection_id':d['state']['pending_reflection']['id'],'alignment':'我完全同意AI我完全同意AI我完全同意AI','verification':'我完全同意AI我完全同意AI我完全同意AI','doubt':'我完全同意AI我完全同意AI我完全同意AI'})
  self.api(p+'/reflection','POST',body,t);teacher=self.teacher()
  code,d=self.api('teacher/'+p,'PATCH',{'review_reflection':True,'reflection_comment':'已与学生讨论，保留其反思，并要求后续补充真实重复测量。'},teacher);self.assertEqual(code,200);self.assertIsNone(d['state']['pending_reflection'])
  self.assertEqual(d['state']['reflections'][-1]['assessment'],'teacher_reviewed')
 def test_metadata_and_comparison_and_manual_rubric(self):
  p,t=self.new();csv='condition,value,unit,measured_at,recording_method,instrument,environment\nA,2,秒,2026-10-25,manual,stopwatch,same height\n'
  code,d=self.api(p+'/csv-import','POST',{'csv':csv,'declared_real':True},t);self.assertEqual(code,200);self.assertEqual(d['state']['observations'][0]['instrument'],'stopwatch')
  teacher=self.teacher()
  for case in range(3):
   code,c=self.api('teacher/comparison','POST',{'case':case,'live':False},teacher);self.assertEqual(code,200);self.assertEqual(c['results']['three']['api_calls'],0);self.assertEqual(len(c['results']['single']['responses']),1);self.assertEqual(len(c['results']['three']['responses']),3)
  ratings={k:{'diversity':3,'evidence_coverage':3,'complete_answer':False,'redundancy_percent':20,'note':'脚本显示了不同职责，但不能由此证明学习效果。'} for k in ['single','three']}
  self.assertEqual(self.api('teacher/comparison/'+c['id'],'PATCH',ratings,teacher)[0],200)
  body={'assessment':{'rubric':{'evidence':{'level':'needs_review','evidence':'仅有一条A条件记录，需更多数据'}},'feedback':'不把填写完整当成能力，需要结合原始记录讨论。'}}
  code,d=self.api('teacher/'+p,'PATCH',body,teacher);self.assertEqual(code,200);self.assertEqual(d['growth']['teacher_assessment']['rubric']['evidence']['level'],'needs_review')
 def test_demo_fixture_never_calls_live_model(self):
  with patch.object(app,'MODE','live'),patch.object(app,'KEY','not-a-real-key'),patch.object(app,'call_kimi',side_effect=AssertionError('Demo must not call Kimi')):
   code,d=self.api('sessions','POST',{'demo_fixture':True});self.assertEqual(code,201)
   p='sessions/'+d['id'];code,d=self.api(p+'/chat','POST',{'message':'请帮助澄清问题'},d['token']);self.assertEqual(code,200);self.assertEqual(d['state']['messages'][-1]['mode'],'demo')
  self.assertEqual(self.api('teacher/comparison','POST',{'case':0,'live':True,'confirm_paid_calls':False},self.teacher())[0],400)
if __name__=='__main__':unittest.main(verbosity=2)
