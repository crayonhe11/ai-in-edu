"""Inquiry workflow, provenance, reflection gates and formative evidence."""
import csv,io,math,re,secrets,time,statistics,random,hashlib
from difflib import SequenceMatcher

def stamp():return int(time.time())
def pair(zh,en):return {'zh':zh,'en':en}
def normalize(s):
 s.setdefault('schema_version',3)
 s.setdefault('profile',{'alias':'学习者-'+secrets.token_hex(2)})
 for k in ['falsifiability','ai_acknowledgement']:s['notebook'].setdefault(k,'')
 s.setdefault('versions',[]);s.setdefault('events',[]);s.setdefault('reviews',[]);s.setdefault('simulations',[]);s.setdefault('reflections',[]);s.setdefault('pending_reflection',None);s.setdefault('report',None)
 for i,m in enumerate(s['messages']):m.setdefault('id',hashlib.sha256((str(i)+m.get('role','')+m.get('content','')).encode()).hexdigest()[:16])
 # Repair old canned replacements: preserve their history but never call them live feedback.
 canned={'我可以帮你检查思路，但核心内容需要你完成。','I can help you review your thinking, but you must write the conclusion and collect the measurements. State your initial idea and what you have actually observed. Without data, we can plan how to collect evidence.'}
 invalid=set()
 for m in s['messages']:
  if m.get('role')!='student' and (m.get('mode')=='system_fallback' or (m.get('mode')=='live' and any(m.get('content','')==x or m.get('content','').startswith(x+'\n\nEnglish:') for x in canned))):
   m['mode']='system_fallback';m['notice']='旧版系统兜底提示，并非Kimi针对稿件的反馈 / Legacy system fallback, not draft-specific Kimi feedback';invalid.add(m['id'])
 pending=s.get('pending_reflection')
 if pending and pending.get('outputs') and all(o.get('message_id') in invalid for o in pending['outputs']):
  s['pending_reflection']=None;record(s,'invalid_fallback_reflection_cancelled',{'reflection_id':pending['id'],'reason':'legacy_canned_response_not_valid_feedback'})
 if invalid:s['feedback_reads']=[x for x in s.get('feedback_reads',[]) if not invalid.intersection(x.get('message_ids',[]))]
 s['topic'].setdefault('unit','秒');s['topic'].setdefault('preset','helicopter')
 for row in s['observations']:
  row.setdefault('source','student_entered');row.setdefault('provenance','student_declared_real');row.setdefault('unit',s['topic']['unit'])
 from learning import upgrade
 return upgrade(s)

def record(s,kind,detail):
 s['events'].append({'id':secrets.token_hex(8),'at':stamp(),'kind':kind,'detail':detail})

def notebook_update(s,patch):
 changes={k:{'before':s['notebook'].get(k,''),'after':v} for k,v in patch.items() if s['notebook'].get(k,'')!=v}
 if changes:
  s['versions'].append({'id':secrets.token_hex(8),'at':stamp(),'stage':s['stage'],'changes':changes})
  s['notebook'].update(patch);record(s,'notebook_revision',{'fields':list(changes)})
  s['report']=None

def require_clear(s):
 if s.get('pending_reflection'):raise ValueError('请先处理AI建议：选择采纳、部分采纳或保留原稿 / Decide whether to adopt, partly adopt or retain your draft')

def gate(s,outputs,kind):
 s['report']=None
 rid=secrets.token_hex(10)
 from learning import draft_context
 snapshot,_=draft_context(s)
 s['pending_reflection']={'id':rid,'at':stamp(),'kind':kind,'outputs':outputs,'stage':s['stage'],'observation_ids':[r['id'] for r in s['observations']],'workflow':'adoption_revision','notebook_snapshot':snapshot}
 record(s,'reflection_required',{'reflection_id':rid,'kind':kind})

def reflect(s,data):
 pending=s.get('pending_reflection')
 if not pending or data.get('reflection_id')!=pending['id']:raise ValueError('反思编号不匹配 / Reflection ID does not match')
 values={k:data.get(k,'').strip() if isinstance(data.get(k),str) else '' for k in ['alignment','verification','doubt']}
 if any(len(v)<10 or len(v)>2000 for v in values.values()):raise ValueError('每项反思须为10至2000个字符 / Each reflection requires 10–2000 characters')
 s['reflections'].append({**pending,**values,'submitted_at':stamp(),'assessment':'completion_only_not_verified_correct'})
 s['pending_reflection']=None;record(s,'reflection_submitted',{'reflection_id':pending['id']})

def configure_topic(s,data):
 require_clear(s)
 if s['stage']!=0:raise ValueError('请先返回问题阶段修改主题 / Return to the question stage to change the topic')
 if s['observations'] or s['simulations']:raise ValueError('已有测量或仿真，请新建会话以免混合探究 / Start a new session to avoid mixing existing data')
 title=data.get('title','');unit=data.get('unit','');preset=data.get('preset','custom')
 if not isinstance(title,str) or not 5<=len(title.strip())<=200 or not isinstance(unit,str) or not 1<=len(unit.strip())<=20:raise ValueError('请填写主题和测量单位 / Provide a topic and measurement unit')
 if preset not in ('helicopter','mung','custom'):raise ValueError('未知主题 / Unknown topic')
 s['topic']={'id':secrets.token_hex(6),'preset':preset,'title':title.strip(),'description':'学生自主提出的科学问题 / A student-authored scientific question','unit':unit.strip(),'safety':'实验前请教师审核材料、场地与步骤。绿豆仅观察，不食用，不使用危险材料。 / Ask a teacher to review the materials, site and procedure. Observe sprouts only. Do not eat them or use hazardous materials.'}
 notebook_update(s,{'question':title.strip()});record(s,'topic_changed',{'title':title.strip(),'unit':unit.strip()})

def plan_review(s):
 nb=s['notebook'];issues=[]
 for field,label in [('independent',pair('自变量','independent variable')),('dependent',pair('因变量','dependent variable')),('controls',pair('控制条件','controlled conditions')),('procedure',pair('实验步骤','procedure')),('falsifiability',pair('可证伪条件','falsifiability condition'))]:
  if len(nb.get(field,'').strip())<5:issues.append({'code':'missing_'+field,'message':pair('请补充或澄清'+label['zh']+'，并说明理由。','Clarify the '+label['en']+' and explain your reasoning.')})
 if not re.search(r'重复|每组|每种|次|repeat|trial|replicat|sample',nb.get('procedure',''),re.I):issues.append({'code':'repeats_unspecified','message':pair('计划尚未说明重复测量安排。你怎样判断一次结果是否偶然？','Repeated measurements are not specified. How will you judge whether one result is accidental?')})
 if nb.get('independent','').strip() and nb.get('independent')==nb.get('dependent'):issues.append({'code':'variables_overlap','message':pair('自变量与因变量填写相同，请解释你改变什么、测量什么。','The two variables match. Explain what you change and what you measure.')})
 if not re.search(r'安全|教师|老师|safety|teacher',nb.get('procedure',''),re.I):issues.append({'code':'teacher_review','message':pair('请说明实验安全安排，并在实际操作前请教师审核。','Describe safety arrangements and ask a teacher to review the plan before experimenting.')})
 r={'id':secrets.token_hex(8),'at':stamp(),'issues':issues,'kind':'rule_based_plan_check','notice':pair('规则检查不能证明方案科学有效或样本量充分。','A rule-based check cannot establish scientific validity or adequate sample size.')}
 s['reviews'].append(r);record(s,'plan_checked',{'review_id':r['id'],'issue_codes':[i['code'] for i in issues]});return r

def number(value,low,high,label):
 if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not low<=value<=high:raise ValueError(label+'超出范围 / out of range')
 return float(value)

def simulate(s,data):
 if any(not s['notebook'].get(k,'').strip() for k in ['independent','dependent','controls','procedure']):raise ValueError('请先填写实验方案 / Write the experiment plan first')
 baseline=number(data.get('baseline'),0,100000,'baseline');effect=number(data.get('effect'),-100000,100000,'effect');noise=number(data.get('noise'),0,100000,'noise')
 n=data.get('trials',3)
 if isinstance(n,bool) or not isinstance(n,int) or not 2<=n<=20:raise ValueError('仿真次数须为2至20 / Use 2–20 simulated trials')
 rng=random.Random(42);rows=[]
 for c in range(2):
  for i in range(n):rows.append({'condition':'A' if c==0 else 'B','trial':i+1,'value':round(baseline+c*effect+rng.uniform(-noise,noise),4),'source':'simulation'})
 r={'id':secrets.token_hex(8),'at':stamp(),'source':'simulation','unit':s['topic']['unit'],'parameters':{'baseline':baseline,'assumed_difference':effect,'noise':noise,'trials':n},'rows':rows,'model':'y = baseline + assumed_group_difference + uniform_noise; fixed seed 42','notice':pair('这只是自设参数的敏感性示意，不是物理或生物预测。仿真不等于真实实验，禁止作为实验证据。','This is a sensitivity illustration using your assumptions, not a physical or biological prediction. Simulation is not a real experiment and must not be used as evidence.'),'prompts':[pair('噪声增大后，条件之间是否更难区分？','Does larger measurement noise make the conditions harder to distinguish?'),pair('哪些条件可能导致重复测量不一致？','Which conditions could make repeated measurements inconsistent?')]}
 s['simulations'].append(r);record(s,'simulation_preview',{'simulation_id':r['id'],'source':'simulation'});return r

def validate_row(s,data):
 if str(data.get('source','')).lower() in ('simulation','simulated','demo_fixture') or str(data.get('provenance','')).lower() in ('simulation','synthetic_demonstration'):raise ValueError('仿真数据不能进入实验证据 / Simulation cannot enter the evidence dataset')
 if data.get('declared_real') is not True:raise ValueError('请确认这些是自行采集的真实测量 / Confirm these are your own real measurements')
 condition=data.get('condition');value=data.get('value');unit=data.get('unit',s['topic']['unit']);note=data.get('note','')
 if not isinstance(condition,str) or not 1<=len(condition.strip())<=60:raise ValueError('请填写条件标签 / Provide a condition label')
 number(value,-1000000000,1000000000,'测量值 / Measurement')
 if s['topic'].get('preset')=='mung' and not 0<=value<=100:raise ValueError('发芽率须为0到100% / Germination rate must be between 0 and 100%')
 if s['topic'].get('preset','helicopter')=='helicopter' and value<=0:raise ValueError('下落时间须大于0 / Fall time must be positive')
 if not isinstance(unit,str) or unit.strip()!=s['topic']['unit']:raise ValueError('测量单位不一致 / Measurement units must match the project')
 if not isinstance(note,str) or len(note)>500:raise ValueError('测量备注最多500字符 / Measurement notes: at most 500 characters')
 return {'id':secrets.token_hex(6),'at':stamp(),'condition':condition.strip(),'value':float(value),'unit':unit.strip(),'note':note,'source':'student_entered','provenance':'student_declared_real',**__import__('learning').metadata(data)}

def import_csv(s,data,commit=False):
 text=data.get('csv','')
 if not isinstance(text,str) or not 1<=len(text)<=45000:raise ValueError('CSV须为UTF-8文本且小于45KB / Use UTF-8 CSV under 45KB')
 if data.get('declared_real') is not True:raise ValueError('请确认上传的是自行采集的真实测量 / Confirm that uploaded data are your real measurements')
 if re.search(r'^\s*#.*(simulation|仿真)',text,re.I|re.M):raise ValueError('文件标记为仿真，禁止导入证据 / File is marked as simulation')
 reader=csv.DictReader(io.StringIO(text.lstrip('\ufeff')))
 if not reader.fieldnames or not {'condition','value','unit'}.issubset(set(reader.fieldnames)):raise ValueError('CSV必须包含condition,value,unit列 / Required CSV columns: condition,value,unit')
 rows=[]
 for i,row in enumerate(reader,2):
  if i>302:raise ValueError('CSV最多300行 / CSV allows at most 300 rows')
  if None in row or any(v is None for v in row.values()):raise ValueError(f'CSV第{i}行列数不一致 / Inconsistent columns at row {i}')
  if row.get('source','').strip().lower() in ('simulation','simulated','仿真','demo_fixture','synthetic_demonstration'):raise ValueError('仿真数据不能导入证据 / Simulated data cannot be imported as evidence')
  try:value=float(row['value'])
  except ValueError:raise ValueError(f'CSV第{i}行测量值不是数值 / Invalid number at row {i}') from None
  rows.append(validate_row(s,{'condition':row['condition'],'value':value,'unit':row['unit'],'note':row.get('note',''),'declared_real':True,**{k:row.get(k,'') for k in ['measured_at','recording_method','instrument','environment','collection_notes']}}))
 if not rows:raise ValueError('CSV没有数据行 / No data rows in CSV')
 if len(rows)+len(s['observations'])>300:raise ValueError('本次探究最多300条测量 / At most 300 measurements per inquiry')
 if commit:
  for r in rows:r['source']='student_csv'
  s['observations'].extend(rows);s['report']=None;record(s,'csv_imported',{'count':len(rows),'filename':str(data.get('filename',''))[:120],'provenance':'student_declared_real',**__import__('learning').metadata(data)})
 return rows

def stats(rows):
 groups={}
 for r in rows:
  if r.get('source')=='simulation':continue
  groups.setdefault(r['condition'],[]).append(r)
 out=[]
 for cond,items in groups.items():
  vals=[r['value'] for r in items];q=statistics.quantiles(vals,n=4,method='inclusive') if len(vals)>=4 else None
  iqr=q[2]-q[0] if q else 0
  flags=[r['id'] for r in items if q and iqr>0 and (r['value']<q[0]-1.5*iqr or r['value']>q[2]+1.5*iqr)]
  out.append({'condition':cond,'n':len(vals),'mean':round(statistics.mean(vals),4),'median':round(statistics.median(vals),4),'sd':round(statistics.stdev(vals),4) if len(vals)>1 else None,'min':min(vals),'max':max(vals),'unit':items[0].get('unit',''),'possible_outlier_ids':flags,'outlier_rule':'1.5 IQR, >=4 trials; flag only, never auto-delete'})
 return out

def formative(s):
 nb=s['notebook'];groups=stats(s['observations']);alerts=[]
 if not nb.get('controls','').strip() and s['stage']>=2:alerts.append({'code':'controls_missing','message':pair('控制变量尚未记录，请教师追问。','Controlled variables are not recorded. A teacher should follow up.')})
 if groups and (len(groups)<2 or min(x['n'] for x in groups)<3):alerts.append({'code':'limited_repetition','message':pair('比较条件或重复测量不足，需复核计划。','Comparison conditions or repeated measurements are limited. Review the plan.')})
 if s.get('pending_reflection'):alerts.append({'code':'reflection_pending','message':pair('AI建议尚未处理，请选择采纳、部分采纳或保留原稿。','An adoption decision on AI feedback is pending.')})
 if any(x['possible_outlier_ids'] for x in groups):alerts.append({'code':'outlier_review','message':pair('部分数值触发IQR异常提示，保留原值并讨论误差。','Some values trigger an IQR flag. Keep the raw values and discuss possible errors.')})
 for field in ['hypothesis','procedure','claim','reasoning']:
  text=nb.get(field,'')
  if len(text)>=40 and any(m.get('role')!='student' and len(m.get('content',''))>=40 and SequenceMatcher(None,text,m['content']).ratio()>=.85 for m in s['messages']):
   alerts.append({'code':'possible_copy','field':field,'message':pair('文字与AI回复高度相似，需教师讨论来源，不能据此判定抄袭。','Text is highly similar to an AI reply. Discuss its source. This does not establish plagiarism.')})
 dims=[('question',bool(nb.get('question','').strip()),False,pair('问题明确化','Question formulation')),('hypothesis',bool(nb.get('hypothesis','').strip()),bool(nb.get('reason','').strip() and nb.get('falsifiability','').strip()),pair('假设与可证伪性','Hypothesis and falsifiability')),('plan',bool(nb.get('procedure','').strip()),all(nb.get(k,'').strip() for k in ['independent','dependent','controls']),pair('公平实验设计','Fair experimental design')),('evidence',bool(groups),len(groups)>=2 and all(x['n']>=3 for x in groups),pair('数据与重复测量','Data and repeated measurement')),('critical',bool(s['reflections']),len(s['reflections'])>=2,pair('AI建议判断与理由','AI feedback decisions and reasons')),('argument',bool(nb.get('claim','').strip()),all(nb.get(k,'').strip() for k in ['evidence','reasoning','limitation']),pair('证据论证与局限','Evidence reasoning and limitations'))]
 return {'alerts':alerts,'indicators':[{'id':i,'label':label,'level':2 if b and a else 1 if a else 0} for i,a,b,label in dims],'notice':pair('0未记录，1已有尝试，2记录较完整。这是过程记录指示，不能替代教师对科学正确性与学习能力的评价。','0 not recorded, 1 attempted, 2 more complete records. These are process indicators, not judgments of scientific correctness or ability.')}

def report_scaffold(s):
 nb=s['notebook'];sections=[('question','研究问题 / Research question'),('hypothesis','假设 / Hypothesis'),('reason','预测依据 / Rationale'),('falsifiability','可证伪条件 / Falsifiability'),('procedure','方法 / Method'),('evidence','结果证据 / Evidence'),('claim','主张 / Claim'),('reasoning','解释 / Reasoning'),('limitation','局限与改进 / Limitations')]
 return [{'field':field,'title':title,'text':nb.get(field,''),'origin':('synthetic_demonstration' if s.get('demo_fixture') else 'student_entered_unverified_authorship'),'scaffold_origin':'platform_template','prompt':pair('请用自己的话填写，并说明依据。','Write in your own words and explain your evidence.')} for field,title in sections]

def build_report(s,data):
 require_clear(s)
 from learning import require_current_draft,NODES
 for step in NODES:require_current_draft({**s,'stage':step})
 required=['question','hypothesis','reason','falsifiability','independent','dependent','controls','procedure','evidence','claim','reasoning','limitation','ai_acknowledgement']
 missing=[x for x in required if not s['notebook'].get(x,'').strip()]
 if missing:raise ValueError('报告仍缺少学生核心内容 / Missing student-authored report fields: '+', '.join(missing))
 if not s['observations']:raise ValueError('没有真实测量记录，不能生成最终报告 / Real measurements are required for a final report')
 if not s.get('demo_fixture') and data.get('confirmed_authorship') is not True:raise ValueError('请确认核心文本由你撰写并已说明AI使用 / Confirm authorship and AI acknowledgement')
 ai_use=data.get('ai_use',[])
 if not isinstance(ai_use,list) or len(ai_use)>30:raise ValueError('AI使用记录格式错误 / Invalid AI use records')
 lookup={m.get('id'):m for m in s['messages'] if m.get('role')!='student'}
 cleaned=[]
 for item in ai_use:
  if not isinstance(item,dict) or item.get('message_id') not in lookup:raise ValueError('AI引用编号无效 / Invalid AI reference ID')
  decision=item.get('decision');reason=item.get('reason','');summary=item.get('summary','');citation=item.get('citation','');final=item.get('rewrite','')
  if decision not in ('adopt','reject','partly') or not isinstance(reason,str) or not 10<=len(reason.strip())<=2000:raise ValueError('请说明采纳、拒绝或部分采纳及其理由 / Explain adoption, rejection or partial adoption')
  if not isinstance(summary,str) or not 10<=len(summary.strip())<=2000 or not isinstance(citation,str) or not 10<=len(citation.strip())<=2000:raise ValueError('请填写AI建议摘要与证据/来源 / Provide the AI suggestion summary and evidence/source')
  if not isinstance(final,str) or len(final)>2000 or (decision!='reject' and len(final.strip())<10):raise ValueError('采纳内容须填写学生最终表述 / Provide your final wording for adopted advice')
  cleaned.append({'message_id':item['message_id'],'original':lookup[item['message_id']]['content'],'original_origin':lookup[item['message_id']].get('mode'),'summary':summary.strip(),'decision':decision,'reason':reason.strip(),'citation':citation.strip(),'rewrite':final.strip(),'rewrite_origin':'student_entered'})
 result={'id':secrets.token_hex(8),'at':stamp(),'topic':s['topic'],'sections':report_scaffold(s),'variables':{k:s['notebook'][k] for k in ['independent','dependent','controls']},'observations':s['observations'],'statistics':stats(s['observations']),'ai_acknowledgement':s['notebook']['ai_acknowledgement'],'ai_use':cleaned,'reflections':s['reflections'],'drafts':s.get('drafts',[]),'revision_decisions':s.get('revision_decisions',[]),'demo_fixture':s.get('demo_fixture',False),'provenance_notice':'学生输入不代表系统已经验证作者身份或实验真实性。仿真不进入报告证据。 / Authorship and real-world data collection are not independently verified. Simulation is excluded from report evidence.'}
 if s.get('demo_fixture'):result['provenance_notice']='虚构演示报告：所有示例数值均非实测，不可作研究证据。 / Fictional demo report: values are not measurements and must not be used as research evidence.'
 s['report']=result;record(s,'report_assembled',{'report_id':result['id']});return result
