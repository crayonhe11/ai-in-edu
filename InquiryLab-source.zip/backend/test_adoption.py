import unittest,copy
from unittest.mock import patch
import server as app, research as r, learning as l
from domain import empty_state
class Adoption(unittest.TestCase):
 def state(self,stage=1):
  s=r.normalize(empty_state());s['stage']=stage
  for k in l.STAGE_EDIT_FIELDS[stage]:s['notebook'][k]='学生提出的原有内容，可通过实验检验'
  if stage in l.NODES:l.submit_draft(s,{})
  return s
 def gate(self,s):r.gate(s,[{'role':'peer','content':'请说明具体测量方式','origin':'demo'}],'agent_round')
 def payload(self,s,decision):
  fields=l.STAGE_EDIT_FIELDS[s['stage']];before={k:s['notebook'][k] for k in fields}
  return {'feedback_id':s['pending_reflection']['id'],'decision':decision,'reason':'我采纳测量建议，补充具体可观察的指标。','baseline':before,'notebook':{} if decision=='reject' else {**before,fields[0]:before[fields[0]]+'，补充具体的测量指标'}}
 def test_selected_roles_only(self):
  s=self.state();calls=[]
  def generate(role,*args):calls.append(role);return '具体角色反馈 '+role,{}
  with patch.object(app,'effective_mode',return_value='live'),patch.object(app,'KEY','test'),patch.object(app,'call_kimi',side_effect=generate),patch.object(app,'review_outputs',side_effect=lambda s,x:(x,{'usage':{}})):
   out=app.round_agents(s,'检查原稿',roles=['peer','skeptic','peer'])
  self.assertEqual(calls,['skeptic','peer']);self.assertEqual([x['role'] for x in out],calls)
 def test_invalid_roles(self):
  for roles in [[],['unknown'],'mentor',[{}]]:
   with self.assertRaises(ValueError):app.selected_roles(roles)
 def test_adoption_all_stages(self):
  for stage in range(5):
   for decision in ['adopt','partly','reject']:
    with self.subTest(stage=stage,decision=decision):
     s=self.state(stage);self.gate(s);data=self.payload(s,decision);old=copy.deepcopy(s['notebook']);l.feedback_decision(s,data)
     self.assertIsNone(s['pending_reflection']);self.assertEqual(s['stage'],stage);self.assertEqual(s['feedback_decisions'][-1]['before'],data['baseline'])
     if decision=='reject':self.assertEqual(old,s['notebook'])
     elif stage in l.NODES:self.assertEqual([x['version'] for x in s['drafts']],[0,1]);self.assertEqual(s['drafts'][0]['snapshot'][l.NODES[stage][1][0]],old[l.NODES[stage][1][0]])
 def test_stale_and_unchanged_rejected(self):
  s=self.state();self.gate(s);data=self.payload(s,'adopt');data['baseline']={};before=copy.deepcopy(s)
  with self.assertRaises(ValueError):l.feedback_decision(s,data)
  self.assertEqual(before,s)
  data=self.payload(s,'adopt');data['notebook']=dict(data['baseline'])
  with self.assertRaises(ValueError):l.feedback_decision(s,data)
  self.assertEqual(before,s)
 def test_back_navigation_edits_feedback_stage(self):
  s=self.state(2);self.gate(s);data=self.payload(s,'partly');s['stage']=1;l.feedback_decision(s,data);self.assertEqual(s['stage'],1);self.assertEqual(s['drafts'][-1]['node'],'plan')
if __name__=='__main__':unittest.main()
