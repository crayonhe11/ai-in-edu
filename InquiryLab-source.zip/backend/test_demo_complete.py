import unittest
import learning as l,research as r,server as app
from domain import empty_state
class CompleteDemo(unittest.TestCase):
 def test_whole_walkthrough(self):
  s=l.demo_setup(r.normalize(empty_state()))
  self.assertTrue(all(s['notebook'].values()))
  for stage in range(5):
   self.assertEqual(s['stage'],stage)
   if stage in l.NODES:self.assertTrue(l.require_current_draft(s))
   if stage==3:self.assertEqual(len(s['observations']),6)
   app.round_agents(s,'请给我反馈',roles=['peer']);self.assertEqual(s['audit'][-1]['order'],['peer'])
   l.demo_next(s);self.assertIsNone(s['pending_reflection'])
  self.assertTrue(s['report']['demo_fixture']);self.assertTrue(all(x['origin']=='synthetic_demonstration' for x in s['report']['sections']))
  self.assertEqual(len(s['feedback_decisions']),5)
 def test_real_session_cannot_auto_complete(self):
  with self.assertRaises(ValueError):l.demo_next(r.normalize(empty_state()))

class DemoLanguages(unittest.TestCase):
 def test_toggle_known_fixtures_and_preserve_edits(self):
  s=l.demo_setup(r.normalize(empty_state()));l.localize_demo(s,'zh');zh=s['notebook']['procedure'];self.assertNotIn('Fictional plan',zh);self.assertNotIn(' / ',zh)
  l.localize_demo(s,'en');self.assertIn('Fictional plan',s['notebook']['procedure']);self.assertNotRegex(s['notebook']['procedure'],r'[\u4e00-\u9fff]')
  l.localize_demo(s,'zh');self.assertEqual(s['notebook']['procedure'],zh)
  custom='这是我亲自修改的记录 / 自定义分隔符';s['notebook']['procedure']=custom;l.localize_demo(s,'en');self.assertEqual(s['notebook']['procedure'],custom)
 def test_english_walkthrough_stays_english(self):
  s=l.demo_setup(r.normalize(empty_state()));l.localize_demo(s,'en')
  for _ in range(5):l.demo_next(s);l.localize_demo(s,'en')
  self.assertTrue(s['report']['demo_fixture'])
  for section in s['report']['sections']:self.assertNotRegex(section['text'],r'[\u4e00-\u9fff]')

class DataFirstFeedback(unittest.TestCase):
 def test_no_feedback_before_data(self):
  s=r.normalize(empty_state());s['stage']=3
  with self.assertRaisesRegex(ValueError,'Record or import'):app.round_agents(s,'请分析我的数据',roles=['peer'])
  self.assertEqual(s['messages'],[])
