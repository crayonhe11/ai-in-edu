"""Draft-first feedback, reflective judgement and descriptive growth evidence."""
import re,secrets,time
from datetime import datetime
from difflib import SequenceMatcher
import research as r
NODES={1:('hypothesis',['hypothesis','reason','falsifiability']),2:('plan',['independent','dependent','controls','procedure']),4:('conclusion',['claim','evidence','reasoning','limitation'])}
RUBRIC={
 'question':r.pair('问题明确性：能指出改变什么、观察什么，且可通过实验回答。','Question clarity: identifies a change and an observable outcome that an experiment can address.'),
 'controls':r.pair('控制变量：说明保持相同的条件及其理由，方法可重复。','Controlled variables: explains what stays constant and why, with repeatable steps.'),
 'evidence':r.pair('证据关联：主张指向具体测量或记录，区分预测与观察。','Evidence links: connects claims to specific measurements and distinguishes prediction from observation.'),
 'limitations':r.pair('误差与局限：考虑操作误差、替代解释和证据边界。','Error and limitations: considers measurement error, alternatives and the limits of evidence.')}

def upgrade(s):
 s['schema_version']=4
 for key in ['drafts','reflection_attempts','revision_decisions','output_reviews','feedback_reads']:s.setdefault(key,[])
 s.setdefault('teacher_assessment',{'rubric':{},'feedback':'','at':None})
 s.setdefault('demo_fixture',False)
 return s

def submit_draft(s,data):
 r.require_clear(s);upgrade(s)
 if s['stage'] not in NODES:raise ValueError('当前步骤不需要核心初稿 / No core draft is required at this stage')
 node,fields=NODES[s['stage']];snapshot={k:s['notebook'].get(k,'').strip() for k in fields}
 if any(len(v)<5 for v in snapshot.values()):raise ValueError('请先自行填写本步全部核心内容，每项至少5字 / Write all core fields yourself, at least 5 characters each')
 previous=[x for x in s['drafts'] if x['node']==node]
 reason=data.get('reason','');decision=data.get('decision','initial')
 if previous:
  if decision not in ('adopt','reject','partly','self_revision'):raise ValueError('请选择采纳、拒绝、部分采纳或自主修订 / Choose a revision decision')
  if not isinstance(reason,str) or not 10<=len(reason.strip())<=2000:raise ValueError('修订需说明理由，至少10个字符 / Explain the revision decision in at least 10 characters')
  if snapshot==previous[-1]['snapshot']:raise ValueError('内容未改变。若保留原稿，请使用保留判断记录 / Draft is unchanged; record a retained judgement instead')
 draft={'id':secrets.token_hex(8),'node':node,'version':len(previous),'at':r.stamp(),'snapshot':snapshot,'decision':decision if previous else 'initial','reason':reason.strip() if isinstance(reason,str) else '','authorship':'student_submitted_not_independently_verified'}
 s['drafts'].append(draft);s['report']=None
 if previous:s['revision_decisions'].append({'draft_id':draft['id'],'node':node,'decision':decision,'reason':reason.strip(),'at':r.stamp()})
 r.record(s,'core_draft_submitted',{'draft_id':draft['id'],'node':node,'version':draft['version']});return draft

def require_draft(s):
 upgrade(s)
 if s['stage'] in NODES:
  node,fields=NODES[s['stage']];found=[x for x in s['drafts'] if x['node']==node]
  if not found:raise ValueError('请先提交自己的核心初稿，再请求AI反馈 / Submit your own core draft before requesting AI feedback')
  return found[-1]
 return None

def retain_decision(s,data):
 r.require_clear(s);draft=require_draft(s)
 if not draft:raise ValueError('此步骤没有核心稿 / No core draft for this stage')
 reason=data.get('reason','');decision=data.get('decision')
 if decision not in ('adopt','reject','partly','self_revision') or not isinstance(reason,str) or not 10<=len(reason.strip())<=2000:raise ValueError('请选择决定并填写至少10字符理由 / Choose a decision and explain it in at least 10 characters')
 record={'id':secrets.token_hex(8),'draft_id':draft['id'],'node':draft['node'],'decision':decision,'reason':reason.strip(),'at':r.stamp(),'retained_snapshot':True}
 s['revision_decisions'].append(record);r.record(s,'judgement_retained',record);s['report']=None

def draft_context(s):
 draft=require_draft(s);nb=dict(s['notebook'])
 if draft:nb.update(draft['snapshot'])
 return nb,draft

def repetition(text):
 clean=re.sub(r'[\W_]+','',text.lower())
 if not clean:return True
 if len(set(clean))/len(clean)<.15:return True
 for width in range(1,min(20,len(clean)//3)+1):
  if len(clean)>=width*3 and clean== (clean[:width]*((len(clean)//width)+1))[:len(clean)]:return True
 return False

def review_reflection(s,data):
 upgrade(s);pending=s.get('pending_reflection')
 if not pending or pending['id']!=data.get('reflection_id'):raise ValueError('反思编号不匹配 / Reflection ID does not match')
 values={k:data.get(k,'').strip() if isinstance(data.get(k),str) else '' for k in ['ai_claim','alignment','verification','doubt']}
 if any(not 10<=len(v)<=2000 for v in values.values()):raise ValueError('请填写AI具体主张及三项反思，每项10–2000字符 / Provide the specific AI statement and three reflections, 10–2000 characters each')
 ids=data.get('evidence_ids',[])
 if not isinstance(ids,list) or not all(isinstance(x,str) for x in ids) or len(ids)>30:raise ValueError('证据编号无效 / Invalid evidence IDs')
 valid={x['id'] for x in s['observations']}
 if set(ids)-valid:raise ValueError('引用的测量不存在 / Referenced measurements do not exist')
 flags=[];texts=list(values.values())
 if any(repetition(x) for x in texts):flags.append(r.pair('内容存在机械重复。请指明一句AI主张，以及你为何相信或怀疑它。','Some text is mechanically repeated. Identify one AI statement and why you trust or doubt it.'))
 if any(SequenceMatcher(None,texts[i],texts[j]).ratio()>.88 for i in range(len(texts)) for j in range(i+1,len(texts))):flags.append(r.pair('几个回答几乎相同。请分别说明证据、查证方式和替代解释。','Several answers are nearly identical. Separate evidence, verification and alternatives.'))
 generic=re.compile(r'^(我(完全|非常|很)?(同意|相信|认可|赞同)(AI|人工智能|这个说法|它)?[，。！!\s]*)+$|^(i (fully |strongly )?agree( with (the )?ai)?[.!\s]*)+$',re.I)
 if generic.match(values['alignment']) or (len(values['alignment'])<50 and re.search(r'同意AI|相信AI|agree with ai',values['alignment'],re.I) and not re.search(r'证据|数据|测量|暂无|没有|evidence|data|measur|no evidence|\d',values['alignment'],re.I)):
  flags.append(r.pair('只有认同还不够。哪条观察或数据支持你的判断？没有数据时请明确说明。','Agreement alone is insufficient. What observation supports your judgement? Explicitly state if evidence is missing.'))
 if s['observations'] and not ids and not re.search(r'\d',values['alignment']):flags.append(r.pair('已有测量记录。请选择或引用一个具体数值，或解释为何这些数据暂不能检验AI主张。','Measurements exist. Select a record, cite a value, or explain why these data cannot yet test the AI statement.'))
 explanation=data.get('explanation','')
 explained=isinstance(explanation,str) and 20<=len(explanation.strip())<=2000 and data.get('retain_judgement') is True
 attempt={'id':secrets.token_hex(8),'reflection_id':pending['id'],'at':r.stamp(),**values,'evidence_ids':ids,'flags':flags,'explanation':explanation.strip() if isinstance(explanation,str) else '', 'quality_notice':r.pair('辅助追问，不是科学正确性评分。可修订、解释自己的判断或请教师复核。','Advisory follow-up, not a correctness score. Revise, explain your judgement, or ask a teacher to review.')}
 s['reflection_attempts'].append(attempt);r.record(s,'reflection_quality_feedback',{'attempt_id':attempt['id'],'flags':len(flags)})
 if flags and not explained:
  pending['quality_feedback']=attempt;return {'accepted':False,'attempt':attempt}
 s['reflections'].append({**pending,**values,'evidence_ids':ids,'submitted_at':r.stamp(),'assessment':'student_explained_needs_teacher_review' if flags else 'specificity_checks_passed_not_verified_correct','quality_feedback':attempt,'explanation':attempt['explanation']})
 s['pending_reflection']=None;r.record(s,'reflection_submitted',{'reflection_id':pending['id'],'assessment':s['reflections'][-1]['assessment']});return {'accepted':True,'attempt':attempt}

def teacher_reflection(s,data):
 upgrade(s);pending=s.get('pending_reflection');comment=data.get('comment','')
 if not pending or not isinstance(comment,str) or not 10<=len(comment.strip())<=2000:raise ValueError('请填写至少10字符的教师复核意见 / Provide at least 10 characters of teacher review')
 attempts=[a for a in s['reflection_attempts'] if a['reflection_id']==pending['id']]
 if not attempts:raise ValueError('学生尚未提交可复核的反思 / No student reflection attempt to review')
 last=attempts[-1];s['reflections'].append({**pending,**{k:last[k] for k in ['ai_claim','alignment','verification','doubt','evidence_ids']},'submitted_at':r.stamp(),'assessment':'teacher_reviewed','teacher_comment':comment.strip()});s['pending_reflection']=None;r.record(s,'teacher_reflection_override',{'reflection_id':pending['id'],'comment':comment.strip()})

def metadata(data):
 out={}
 for key in ['measured_at','recording_method','instrument','environment','collection_notes']:
  value=data.get(key,'')
  if not isinstance(value,str) or len(value)>500:raise ValueError('数据来源字段须为500字以内文本 / Data-source metadata must be text under 500 characters')
  out[key]=value.strip()
 if out['measured_at']:
  try:datetime.fromisoformat(out['measured_at'].replace('Z','+00:00'))
  except ValueError:raise ValueError('测量时间请使用ISO日期或日期时间 / Use an ISO date or datetime for measurement time') from None
 return out

def growth(s):
 upgrade(s);cards=[]
 for node in ['hypothesis','plan','conclusion']:
  versions=[d for d in s['drafts'] if d['node']==node]
  cards.append({'node':node,'initial':versions[0] if versions else None,'latest':versions[-1] if versions else None,'revision_decisions':[d for d in s['revision_decisions'] if d['node']==node]})
 return {'draft_comparisons':cards,'rubric':RUBRIC,'teacher_assessment':s['teacher_assessment'],'notice':r.pair('对比是成长证据的入口，不自动证明发生了学习。量规为描述性辅助，教师可覆盖建议并引用原始记录。','Comparisons are evidence for discussion, not proof of learning. The rubric is descriptive. Teachers can override suggestions and cite original records.')}

def teacher_assess(s,data):
 upgrade(s)
 if not isinstance(data,dict):raise ValueError('教师评价格式无效 / Invalid teacher assessment')
 values=data.get('rubric',{});feedback=data.get('feedback','')
 if not isinstance(values,dict) or set(values)-set(RUBRIC) or not isinstance(feedback,str) or len(feedback)>3000:raise ValueError('教师评价格式无效 / Invalid teacher assessment')
 for value in values.values():
  if not isinstance(value,dict) or value.get('level') not in ('not_observed','emerging','supported','needs_review') or not isinstance(value.get('evidence',''),str) or len(value['evidence'])>2000:raise ValueError('请使用描述性等级并引用过程证据 / Use descriptive levels and evidence')
 previous=s['teacher_assessment'];scores=data.get('scores',previous.get('scores'));rationale=data.get('score_reasons',previous.get('score_reasons',{}))
 if scores is not None and (not isinstance(scores,dict) or set(scores)!=set(RUBRIC) or any(isinstance(x,bool) or not isinstance(x,int) or not 0<=x<=25 for x in scores.values())):raise ValueError('四项评分均需为0至25的整数 / Each of the four scores must be an integer from 0 to 25')
 if not isinstance(rationale,dict) or set(rationale)-set(RUBRIC) or any(not isinstance(x,str) or len(x)>1000 for x in rationale.values()):raise ValueError('评分依据格式无效 / Invalid score reasons')
 s['teacher_assessment']={'rubric':values,'feedback':feedback,'at':r.stamp(),'author':'teacher','overrides_automated_indicators':True,'scores':scores,'total':sum(scores.values()) if scores is not None else None,'maximum':100,'score_reasons':rationale}
 r.record(s,'teacher_descriptive_assessment',s['teacher_assessment'])

def demo_setup(s):
 upgrade(s);s['demo_fixture']=True;s['profile']['alias']='演示学习者 / Demo learner';s['topic'].update({'preset':'mung','title':'光照时间如何影响绿豆发芽率？ / How does light duration affect mung-bean germination rate?','unit':'%','description':'离线脚本与虚构示例，不是真实学生或实验数据 / Offline scripts and fictional examples, not real student or experimental data'})
 s['demo_complete']=True
 s['notebook'].update(DEMO_NOTEBOOK)
 s['notebook']['question']=s['topic']['title'];r.record(s,'demo_fixture_created',{'synthetic':True});return s

def demo_rows(s):
 r.require_clear(s)
 if not s.get('demo_fixture') or s['stage']!=3:raise ValueError('仅演示会话的数据步骤可载入虚构数据 / Only a demo session at the data step can load fictional data')
 if s['observations']:raise ValueError('已有数据，不能重复载入 / Data already exist')
 for cond,values in [('4h',[60,70,65]),('8h',[65,75,70])]:
  for value in values:s['observations'].append({'id':secrets.token_hex(6),'at':r.stamp(),'condition':cond,'value':value,'unit':'%','note':'虚构软件演示数据 / Fictional software-demo value','source':'demo_fixture','provenance':'synthetic_demonstration','measured_at':'','recording_method':'fictional fixture','instrument':'not measured','environment':'assumed equal','collection_notes':'No real experiment performed'})
 r.record(s,'fictional_demo_data_loaded',{'count':6,'not_real_evidence':True})

def require_current_draft(s):
 draft=require_draft(s)
 if draft:
  _,fields=NODES[s['stage']]
  if any(s['notebook'].get(k,'').strip()!=draft['snapshot'].get(k,'').strip() for k in fields):raise ValueError('核心内容已修改，请提交修订并说明理由 / Submit the revised draft and explain your decision before continuing')
 return draft


def mark_feedback_read(s,data):
 draft=require_draft(s)
 if not draft or data.get('draft_id')!=draft['id']:raise ValueError('反馈对应版本已改变，请刷新 / Feedback draft changed; refresh')
 messages=[m for m in s['messages'] if m.get('draft_id')==draft['id'] and m.get('role') in ('mentor','skeptic','peer') and m.get('mode') in ('live','demo')]
 if not messages:raise ValueError('尚未获得本版本AI反馈 / No AI feedback for this draft yet')
 receipt={'draft_id':draft['id'],'message_ids':[m['id'] for m in messages],'at':r.stamp()}
 s.setdefault('feedback_reads',[]).append(receipt);r.record(s,'feedback_read',receipt)


STAGE_EDIT_FIELDS={0:['question'],1:NODES[1][1],2:NODES[2][1],3:['evidence'],4:NODES[4][1]+['ai_acknowledgement']}
def feedback_decision(s,data):
 """Commit the student's decision and edits together; failed requests save neither."""
 upgrade(s);pending=s.get('pending_reflection')
 if not pending or pending['id']!=data.get('feedback_id'):raise ValueError('反馈已更新，请重新打开 / Feedback changed; reopen the editor')
 stage=pending['stage'];fields=STAGE_EDIT_FIELDS[stage];decision=data.get('decision');reason=data.get('reason','')
 if decision not in ('adopt','partly','reject'):raise ValueError('请选择采纳、部分采纳或保留原稿 / Choose an adoption decision')
 if not isinstance(reason,str) or not 10<=len(reason.strip())<=2000:raise ValueError('请说明理由，至少10个字符 / Explain your decision in at least 10 characters')
 before={k:s['notebook'].get(k,'') for k in fields}
 if data.get('baseline')!=before:raise ValueError('记录已在其他窗口改变，请重新打开编辑 / Notes changed in another window; reopen the editor')
 patch=data.get('notebook',{})
 if not isinstance(patch,dict) or set(patch)-set(fields):raise ValueError('修订字段无效 / Invalid revision fields')
 if decision!='reject':
  from domain import validate_notebook
  patch=validate_notebook(patch)
  if set(patch)!=set(fields) or any(len(patch[k].strip())<5 for k in fields if k!='ai_acknowledgement'):raise ValueError('请自行完善每项内容，至少5个字符 / Complete each field yourself, at least 5 characters')
  if all(patch[k]==before[k] for k in fields):raise ValueError('内容尚未修改；若无需修改，请选择保留原稿 / No edits made; choose retain draft if no revision is needed')
 elif patch:raise ValueError('保留原稿不能同时提交修改 / Retaining the draft cannot include edits')
 original_stage=s['stage'];s['pending_reflection']=None;s['stage']=stage
 try:
  if decision!='reject':
   r.notebook_update(s,patch)
   if stage in NODES:submit_draft(s,{'decision':decision,'reason':reason})
  after={k:s['notebook'].get(k,'') for k in fields}
  entry={'id':secrets.token_hex(8),'feedback_id':pending['id'],'node':NODES[stage][0] if stage in NODES else ('question' if stage==0 else 'evidence'),'stage':stage,'decision':decision,'reason':reason.strip(),'at':r.stamp(),'before':before,'after':after,'outputs':pending['outputs'],'retained_snapshot':decision=='reject'}
  s.setdefault('feedback_decisions',[]).append(entry)
  if decision=='reject' or stage not in NODES:s['revision_decisions'].append(entry)
  s['reflections'].append({**pending,'decision':decision,'alignment':reason.strip(),'verification':'学生采纳决定，不代表科学事实已核验 / Student decision; scientific facts are not verified','doubt':'见学生采纳理由 / See student decision reason','submitted_at':r.stamp(),'assessment':'student_adoption_decision_not_fact_verified'})
  r.record(s,'feedback_decision_submitted',entry);s['report']=None
 finally:s['stage']=original_stage


# Authored fixture text, never a real student's work or measured evidence.
DEMO_NOTEBOOK={
 'hypothesis':'示例猜想：在其他条件相同的情况下，每天光照8小时组的绿豆发芽率可能高于4小时组。 / Example hypothesis: with other conditions equal, the 8-hour light group may have a higher germination rate than the 4-hour group.',
 'reason':'示例依据：光照可能改变种子所处的环境。但这只是待检验的猜想，不能预先认定增加光照一定促进发芽。 / Example rationale: light may change the seeds’ environment. This is a prediction to test, not an established effect.',
 'falsifiability':'若重复实验中8小时组的发芽率没有高于4小时组，或差异随重复而改变，原猜想便缺少支持，需要修订。 / If repeated trials show no higher rate in the 8-hour group, or the direction varies, the hypothesis lacks support and needs revision.',
 'independent':'每日光照时长：4小时与8小时；使用同一光源并固定距离。 / Daily light duration: 4 versus 8 hours, using the same light source at a fixed distance.',
 'dependent':'第3天的发芽率（%）：以胚根伸出至少2毫米为示例判定标准，发芽粒数÷每组种子总数×100%。 / Day-3 germination percentage: for this example, count seeds with a radicle of at least 2 mm, divided by the group total, times 100.',
 'controls':'同批绿豆、每份20粒、同种容器和垫材、相同加水量及补水规则；保持温度条件一致并记录。 / Same seed batch, 20 seeds per replicate, identical containers and substrate, equal watering rules; keep temperature conditions comparable and record them.',
 'procedure':'虚构实验方案示例：4小时与8小时各设置3份，每份20粒。随机分配种子，按统一规则加水，固定时刻观察，连续3天记录；同时记录温度以检查混杂。观察后洗手，绿豆不食用，灯具由教师检查。以下数据仅为演示编造，没有实际开展此实验。 / Fictional plan: three replicates per light condition, 20 seeds each. Randomly allocate seeds, use consistent watering, observe at fixed times for three days, and log temperature as a potential confound. Wash hands, do not eat the seeds, and ask a teacher to check the lamp. No real experiment was performed.',
 'evidence':'虚构演示数据：4小时组三次发芽率为60%、70%、65%，平均65%；8小时组为65%、75%、70%，平均70%。均值相差5个百分点，但两组数值存在重叠。这些数值不是实测证据。 / Fictional values: 4-hour replicates are 60%, 70%, 65% (mean 65%); 8-hour replicates are 65%, 75%, 70% (mean 70%). The mean difference is 5 percentage points, with overlap. These are not measurements.',
 'claim':'仅就虚构数值而言，8小时组的平均发芽率略高。不能据此宣称光照导致发芽率提高，更不能推广到真实实验。 / Within the fictional example, the 8-hour group has a slightly higher mean. This does not establish a causal effect or a real-world finding.',
 'reasoning':'示例推理：比较重复记录比只比较单次值更稳妥。组间有重叠，重复数很少，温度与种子差异也可能影响结果；因此该示例用于练习证据边界，不用于证明科学结论。 / Example reasoning: compare replicates rather than single values. Overlap, few replicates, temperature and seed variation limit interpretation. Use this example to discuss evidence limits, not to establish a scientific conclusion.',
 'limitation':'示例局限：只有每条件3份，未排除全部环境差异，而且数值是虚构的。真正研究应先实施安全审核，再增加独立重复、记录温度、统一计数标准，并收集真实数据。 / Limitations: only three replicates per condition, unresolved environmental differences, and fictional values. A real study requires safety review, more independent replicates, temperature records, consistent counting and actual data collection.',
 'ai_acknowledgement':'本页文字、理由和数值均为预置离线演示，不代表学生独立完成。AI角色回复为脚本示例，没有调用Kimi，亦未核实科学事实。 / Text, reasons and values are prefilled offline fixtures, not independent student work. Role replies are scripted, do not call Kimi and do not verify scientific facts.'
}
def demo_prepare_stage(s):
 if not s.get('demo_fixture'):raise ValueError('仅离线演示可自动准备内容 / Only offline demonstrations can auto-prepare content')
 upgrade(s)
 if s['stage']==3 and not s['observations']:demo_rows(s)
 if s['stage'] in NODES:
  node,keys=NODES[s['stage']];previous=[d for d in s['drafts'] if d['node']==node]
  if not previous or any(s['notebook'][k].strip()!=previous[-1]['snapshot'][k] for k in keys):
   draft=submit_draft(s,{'decision':'self_revision','reason':'离线演示预置内容或手动调整，非真实学生提交 / Prefilled demo or manual example edits, not real student work'})
   draft['authorship']='synthetic_demonstration'

def demo_next(s):
 if not s.get('demo_fixture'):raise ValueError('真实探究不能使用演示自动完成 / Real inquiry cannot use demo auto-completion')
 pending=s.get('pending_reflection')
 if pending:
  keys=STAGE_EDIT_FIELDS[pending['stage']]
  feedback_decision(s,{'feedback_id':pending['id'],'decision':'reject','reason':'示例决定：暂时保留当前表述；需要实际测量才能判断建议，离线演示不提供真实证据。 / Example decision: retain the text pending real measurements; offline examples are not evidence.','baseline':{k:s['notebook'].get(k,'') for k in keys}})
  s['feedback_decisions'][-1]['origin']='synthetic_demo_auto_decision'
 demo_prepare_stage(s)
 if s['stage']<4:
  before=s['stage'];s['stage']+=1;demo_prepare_stage(s);r.record(s,'demo_stage_advanced',{'from':before,'to':s['stage'],'synthetic':True})
 else:
  r.build_report(s,{'confirmed_authorship':False,'ai_use':[]})
  s['report']['authorship_notice']='预置虚构演示，未声明真实学生作者身份 / Prefilled fictional demo; no real student authorship claimed'
 return s

DEMO_STATIC_TEXT=[
 '虚构预置记录 / fictional fixture','未进行测量 / not measured','假定条件一致 / assumed equal','未实际开展实验 / No real experiment performed',
 '示例理由：保留当前表述，待收集真实数据后再判断是否修改。 / Example reason: retain the text until real measurements allow a decision.',
 '示例理由：采纳关于明确测量方法和证据边界的建议，补充说明，仍需真实实验检验。 / Example reason: clarify measurements and evidence limits; real experiments are still needed.',
 '演示补充：进一步明确操作或判断标准，记录可能的混杂因素；目前没有真实实验数据，不能作事实结论。 / Demo addition: clarify operational criteria and possible confounds; without actual data, no factual conclusion follows.',
 '演示学习者 / Demo learner',
 '光照时间如何影响绿豆发芽率？ / How does light duration affect mung-bean germination rate?',
 '离线脚本与虚构示例，不是真实学生或实验数据 / Offline scripts and fictional examples, not real student or experimental data',
 '虚构软件演示数据 / Fictional software-demo value',
 '虚构演示报告：所有示例数值均非实测，不可作研究证据。 / Fictional demo report: values are not measurements and must not be used as research evidence.',
 '预置虚构演示，未声明真实学生作者身份 / Prefilled fictional demo; no real student authorship claimed',
 '示例决定：暂时保留当前表述；需要实际测量才能判断建议，离线演示不提供真实证据。 / Example decision: retain the text pending real measurements; offline examples are not evidence.',
 '离线演示预置内容或手动调整，非真实学生提交 / Prefilled demo or manual example edits, not real student work',
 '研究问题 / Research question','假设 / Hypothesis','预测依据 / Rationale','可证伪条件 / Falsifiability','方法 / Method','结果证据 / Evidence','主张 / Claim','解释 / Reasoning','局限与改进 / Limitations',
 '学生采纳决定，不代表科学事实已核验 / Student decision; scientific facts are not verified','见学生采纳理由 / See student decision reason',
 '实验前请教师审核材料、场地与步骤。绿豆仅观察，不食用，不使用危险材料。 / Ask a teacher to review the materials, site and procedure. Observe sprouts only. Do not eat them or use hazardous materials.'
]
def localize_demo(s,language='zh'):
 """Translate known authored fixtures only. Never split or translate arbitrary student edits."""
 if not s.get('demo_fixture'):raise ValueError('仅演示内容支持预置语言切换 / Only demo fixtures support preset language switching')
 if language not in ('zh','en','bi'):raise ValueError('不支持的语言 / Unsupported language')
 from domain import localized_demo
 mapping={}
 for text in list(DEMO_NOTEBOOK.values())+DEMO_STATIC_TEXT:
  zh,en=text.split(' / ',1);target=zh if language=='zh' else en if language=='en' else text
  for source in (text,zh,en):mapping[source]=target
 for role,zh,en in [('mentor','探究导师','Inquiry mentor'),('skeptic','思辨质疑者','Critical questioner'),('peer','协作同伴','AI peer')]:
  for source in (zh,en):mapping[source]=zh if language=='zh' else en if language=='en' else zh+' / '+en
  for stage in range(5):
   for obs in (s['observations'],[]):
    context={**s,'stage':stage,'observations':obs}
    zhtext=localized_demo(role,context,'',[],'zh');entext=localized_demo(role,context,'',[],'en');target=zhtext if language=='zh' else entext if language=='en' else zhtext+'\n\nEnglish: '+entext
    for source in (zhtext,entext,zhtext+'\n\nEnglish: '+entext):mapping[source]=target
 def walk(value):
  if isinstance(value,str):return mapping.get(value,'\n\n'.join(mapping.get(part,part) for part in value.split('\n\n')))
  if isinstance(value,list):return [walk(v) for v in value]
  if isinstance(value,dict):
   # Preserve manually authored messages verbatim.
   if value.get('role')=='student':return value
   return {k:walk(v) for k,v in value.items()}
  return value
 localized=walk(s);s.clear();s.update(localized);s['demo_language']=language
 return s
