"""Offline integration tests, including mocked Kimi. No paid calls."""
import unittest,tempfile,threading,json,os
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from unittest.mock import patch
import server as app
import research
from domain import empty_state,FIELDS,protect_core_output
class MockKimi(BaseHTTPRequestHandler):
 requests=[];fail=False
 def log_message(self,*a):pass
 def do_POST(self):
  payload=json.loads(self.rfile.read(int(self.headers['Content-Length'])));self.requests.append((self.path,payload,self.headers.get('Authorization')))
  self.send_response(429 if self.fail else 200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(json.dumps({'choices':[{'message':{'content':'SAFE' if payload['messages'][0]['content'].startswith('Review educational') else ('What evidence supports your idea? '+payload['messages'][0]['content'].split('当前角色：')[-1].split('。')[0])}}],'usage':{'total_tokens':15}}).encode())
class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  with app.LOCK:app.RATE.clear()
  cls.tmp=tempfile.TemporaryDirectory();app.DB=cls.tmp.name+'/test.sqlite3';cls.http=ThreadingHTTPServer(('127.0.0.1',0),app.Handler);threading.Thread(target=cls.http.serve_forever,daemon=True).start();cls.base='http://127.0.0.1:'+str(cls.http.server_port)
  cls.mock=ThreadingHTTPServer(('127.0.0.1',0),MockKimi);threading.Thread(target=cls.mock.serve_forever,daemon=True).start();cls.env=patch.dict(os.environ,{'TEACHER_PASSWORD':'local-test-access','KIMI_MAX_RETRIES':'0'});cls.env.start()
 @classmethod
 def tearDownClass(cls):cls.http.shutdown();cls.mock.shutdown();cls.http.server_close();cls.mock.server_close();cls.env.stop();cls.tmp.cleanup()
 def api(self,path,method='GET',data=None,token='',origin=None):
  headers={'Content-Type':'application/json','Authorization':'Bearer '+token}
  if origin:headers['Origin']=origin
  req=Request(self.base+'/api/'+path,data=json.dumps(data).encode() if data is not None else None,method=method,headers=headers)
  try:
   with urlopen(req) as r:return r.status,json.load(r)
  except HTTPError as e:return e.code,json.load(e)
 def new(self):
  code,d=self.api('sessions','POST',{});self.assertEqual(code,201);return 'sessions/'+d['id'],d['token']
 def teacher(self):
  code,d=self.api('teacher/login','POST',{'password':'local-test-access'});self.assertEqual(code,200);return d['token']
 def complete_reflection(self,p,t):
  d=self.api(p,token=t)[1];pending=d['state']['pending_reflection'];self.assertIsNotNone(pending)
  return self.api(p+'/reflection','POST',{'reflection_id':pending['id'],'ai_claim':pending['outputs'][0]['content'][:200],'alignment':'目前还没有真实数据，不能确认AI说法。','verification':'需要查阅课本实验章节并与教师核对。','doubt':'我怀疑环境和操作差异也会影响测量。'},t)
 def test_feedback_requires_successful_version_bound_reply(self):
  p,t=self.new()
  self.api(p+'/notebook','PATCH',{'notebook':{'question':'我想研究光照和种子发芽的关系。'}},t)
  self.assertEqual(self.api(p+'/advance','POST',{},t)[0],200)
  self.api(p+'/notebook','PATCH',{'notebook':{'hypothesis':'我预测不同光照时长的发芽率可能不同。','reason':'这是学生自己的待检验预测，需要实验证据。','falsifiability':'如果各组重复测量相近，我会修改预测。'}},t)
  code,d=self.api(p+'/draft','POST',{},t);self.assertEqual(code,200);did=d['state']['drafts'][-1]['id']
  self.assertEqual(self.api(p+'/feedback-read','POST',{'draft_id':did},t)[0],400)
  code,d=self.api(p+'/chat','POST',{'message':'请检查我初稿里的变量和证据。'},t);self.assertEqual(code,200)
  feedback=[m for m in d['state']['messages'] if m.get('draft_id')==did]
  self.assertEqual(len(feedback),3)
  self.assertEqual(self.api(p+'/feedback-read','POST',{'draft_id':'wrong-version'},t)[0],400)
  code,d=self.api(p+'/feedback-read','POST',{'draft_id':did},t);self.assertEqual(code,200)
  self.assertEqual(d['state']['feedback_reads'][-1]['message_ids'],[m['id'] for m in feedback]);self.assertTrue(d['state']['pending_reflection'])
 def test_auth_and_old_state_migration(self):
  p,t=self.new();self.assertEqual(self.api(p,token='bad')[0],403)
  self.assertEqual(self.api('sessions','POST',{},origin='https://evil.example')[0],403)
  self.assertEqual(self.api(p+'/teacher','PATCH',{'note':'I am a teacher','paused':True},t)[0],403)
  self.assertEqual(self.api('teacher/sessions',token=t)[0],403)
  old=empty_state();old['notebook'].pop('falsifiability',None);normalized=research.normalize(old)
  self.assertIn('falsifiability',normalized['notebook']);self.assertEqual(normalized['observations'],[])
 def test_mandatory_reflection_survives_reload_and_all_actions(self):
  p,t=self.new();code,d=self.api(p+'/chat','POST',{'message':'我准备开展一个科学探究，请提出问题。','language':'bi'},t);self.assertEqual(code,200)
  self.assertIn('English:',d['state']['messages'][-1]['content']);rid=d['state']['pending_reflection']['id']
  for endpoint,data in [('chat',{'message':'再问一个问题'}),('advance',{}),('simulation',{}),('plan-review',{}),('observations',{'condition':'A','value':1,'declared_real':True}),('csv-preview',{'csv':'x'}),('report',{})]:
   self.assertEqual(self.api(p+'/'+endpoint,'POST',data,t)[0],400,endpoint)
  self.assertEqual(self.api(p+'/back','POST',{},t)[0],200)
  self.assertEqual(self.api(p,token=t)[1]['state']['pending_reflection']['id'],rid)
  self.assertEqual(self.api(p+'/reflection','POST',{'reflection_id':rid,'alignment':'x','verification':'x','doubt':'x'},t)[0],400)
  self.assertEqual(self.complete_reflection(p,t)[0],200)
  self.assertIsNone(self.api(p,token=t)[1]['state']['pending_reflection'])
 def test_custom_topic_csv_simulation_and_report(self):
  p,t=self.new();self.assertEqual(self.api(p+'/topic','POST',{'title':'光照时间如何影响绿豆发芽率？','unit':'%','preset':'mung'},t)[0],200)
  for stage in range(4):
   fields=app.STAGES[stage][2]
   code,d=self.api(p+'/notebook','PATCH',{'notebook':{f:'学生自行书写的探究内容，包括重复三次并请教师检查安全。' for f in fields}},t);self.assertEqual(code,200)
   if stage in (1,2):self.assertEqual(self.api(p+'/draft','POST',{},t)[0],200)
   if stage==2:
    code,d=self.api(p+'/plan-review','POST',{'language':'en'},t);self.assertEqual(code,200);self.assertTrue(d['state']['pending_reflection']);self.complete_reflection(p,t)
    code,d=self.api(p+'/simulation','POST',{'baseline':40,'effect':5,'noise':10,'trials':3},t);self.assertEqual(code,200);self.assertEqual(len(d['state']['observations']),0)
    self.assertEqual(d['state']['simulations'][0]['source'],'simulation')
   if stage==3:
    csv='condition,value,unit,note,source\nA,20,%,counted,student_csv\nA,30,%,counted,student_csv\nA,40,%,counted,student_csv\nB,40,%,counted,student_csv\nB,50,%,counted,student_csv\nB,60,%,counted,student_csv\n'
    self.assertEqual(self.api(p+'/csv-preview','POST',{'csv':csv,'declared_real':True},t)[0],200)
    self.assertEqual(len(self.api(p,token=t)[1]['state']['observations']),0)
    self.assertEqual(self.api(p+'/csv-import','POST',{'csv':csv.replace('student_csv','simulation'),'declared_real':True},t)[0],400)
    self.assertEqual(self.api(p+'/csv-import','POST',{'csv':csv.replace('%,','s,',1),'declared_real':True},t)[0],400)
    code,d=self.api(p+'/csv-import','POST',{'csv':csv,'declared_real':True},t);self.assertEqual(code,200);self.assertEqual(len(d['state']['observations']),6)
   self.assertEqual(self.api(p+'/advance','POST',{},t)[0],200)
  self.api(p+'/notebook','PATCH',{'notebook':{f:'学生自己形成的论点、证据、解释、局限或AI使用声明。' for f in ['claim','evidence','reasoning','limitation','ai_acknowledgement']}},t)
  self.assertEqual(self.api(p+'/draft','POST',{},t)[0],200)
  self.assertEqual(self.api(p+'/report','POST',{'confirmed_authorship':False},t)[0],400)
  ai=self.api(p,token=t)[1]['state']['messages'][-1]
  self.assertEqual(self.api(p+'/report','POST',{'confirmed_authorship':True,'ai_use':[{'message_id':ai['id'],'rewrite':ai['content'],'citation':'我记录了AI角色与教材页码，等待核查。'}]},t)[0],400)
  code,referenced=self.api(p+'/report','POST',{'confirmed_authorship':True,'ai_use':[{'message_id':ai['id'],'summary':'AI建议我检查控制变量与重复测量。','decision':'partly','reason':'我采纳变量检查，但不据此推断任何科学结论。','rewrite':'我重新表达为：先说明控制条件，再讨论重复测量带来的不确定性。','citation':'引用上述AI片段作为思考提示，并准备查阅科学教材实验章节。'}]},t)
  self.assertEqual(code,200);self.assertEqual(referenced['state']['report']['ai_use'][0]['rewrite_origin'],'student_entered')
  code,d=self.api(p+'/report','POST',{'confirmed_authorship':True,'ai_use':[]},t);self.assertEqual(code,200);self.assertEqual(len(d['state']['report']['observations']),6)
  self.assertTrue(all(x['source']!='simulation' for x in d['state']['report']['observations']))
  self.api(p+'/notebook','PATCH',{'notebook':{'claim':'学生修改了核心论点，需要重新组装报告。'}},t)
  self.assertIsNone(self.api(p,token=t)[1]['state']['report'])
 def test_teacher_dashboard_history_and_pause(self):
  p,t=self.new();self.api(p+'/notebook','PATCH',{'notebook':{'hypothesis':'学生第一个猜想'}},t);self.api(p+'/notebook','PATCH',{'notebook':{'hypothesis':'学生修改后的猜想'}},t)
  teacher=self.teacher();code,d=self.api('teacher/sessions',token=teacher);self.assertEqual(code,200);self.assertTrue(any(x['id']==p.split('/')[1] for x in d['sessions']))
  code,d=self.api('teacher/'+p,token=teacher);self.assertEqual(code,200);self.assertEqual(len(d['state']['versions']),2)
  self.assertEqual(d['state']['versions'][1]['changes']['hypothesis']['before'],'学生第一个猜想')
  self.api('teacher/'+p,'PATCH',{'note':'请先补充控制变量','paused':True},teacher)
  self.assertEqual(self.api(p+'/chat','POST',{'message':'如何开展探究？'},t)[0],400)
  self.assertEqual(self.api(p,token=t)[1]['state']['teacher']['note'],'请先补充控制变量')
  self.assertEqual(self.api('teacher/'+p,'PATCH',{'note':'x','paused':True},t)[0],403)
 def test_real_measurement_declaration_validation_and_outlier(self):
  p,t=self.new()
  self.assertEqual(self.api(p+'/observations','POST',{'condition':'A','value':2},t)[0],400)
  self.assertEqual(self.api(p+'/observations','POST',{'condition':'A','value':2,'source':'simulation','declared_real':True},t)[0],400)
  for v in [1,1,1,10]:self.assertEqual(self.api(p+'/observations','POST',{'condition':'A','value':v,'declared_real':True},t)[0],200)
  d=self.api(p,token=t)[1];self.assertEqual(len(d['state']['observations']),4);self.assertEqual(len(d['statistics'][0]['possible_outlier_ids']),1)
  self.assertEqual(len(d['state']['observations']),4)
 def test_live_contract_sequential_failure_and_output_guard(self):
  MockKimi.requests=[];MockKimi.fail=False
  with patch.object(app,'BASE','http://127.0.0.1:'+str(self.mock.server_port)),patch.object(app,'KEY','test-not-real'),patch.object(app,'MODE','live'):
   s=research.normalize(empty_state());app.round_agents(s,'Help me investigate.','en');self.assertEqual(len(MockKimi.requests),4)
   for i,(path,payload,auth) in enumerate(MockKimi.requests[:3]):
    self.assertEqual(path,'/chat/completions');self.assertEqual(auth,'Bearer test-not-real')
    context=json.loads(payload['messages'][1]['content'].split('\n',1)[1]);self.assertEqual(len(context['this_round_prior_agents']),i)
   self.assertTrue(s['pending_reflection']);MockKimi.fail=True;s=research.normalize(empty_state())
   with self.assertRaises(RuntimeError):app.round_agents(s,'Help me investigate.')
   self.assertEqual(s['rounds'],0);self.assertEqual(s['messages'],[]);MockKimi.fail=False
  self.assertIn('your own',protect_core_output('Hypothesis: Light always helps seeds.','en'))
if __name__=='__main__':unittest.main(verbosity=2)
