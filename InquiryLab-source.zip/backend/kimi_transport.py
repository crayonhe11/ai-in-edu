"""Verified HTTPS transport, including macOS system trust roots."""
import os,ssl,sys,subprocess,socket,threading,time
CONTROL=threading.local()
from functools import lru_cache
from urllib.error import URLError

@lru_cache(maxsize=1)
def tls_context():
 context=ssl.create_default_context()
 if sys.platform=='darwin':
  # Export certificates only, never private keys. Keep hostname and chain checks enabled.
  for keychain in ['/Library/Keychains/System.keychain','/System/Library/Keychains/SystemRootCertificates.keychain']:
   try:
    result=subprocess.run(['/usr/bin/security','find-certificate','-a','-p',keychain],capture_output=True,text=True,timeout=10)
    if result.returncode==0 and '-----BEGIN CERTIFICATE-----' in result.stdout:context.load_verify_locations(cadata=result.stdout)
   except (OSError,subprocess.TimeoutExpired,ssl.SSLError):pass
 bundle=os.getenv('KIMI_CA_BUNDLE','').strip()
 if bundle:context.load_verify_locations(cafile=bundle)
 return context

def connection_error(exc):
 reason=getattr(exc,'reason',exc)
 if isinstance(reason,ssl.SSLCertVerificationError) or 'CERTIFICATE_VERIFY_FAILED' in str(reason):return 'Kimi HTTPS证书校验失败：请检查系统信任证书，或在后端设置 KIMI_CA_BUNDLE 为可信CA证书文件。 / Kimi TLS certificate verification failed. Check system trust or configure KIMI_CA_BUNDLE.'
 if isinstance(reason,(TimeoutError,socket.timeout)):return 'Kimi回复等待超时；可稍后重试，或在后端调整 KIMI_TIMEOUT。 / Kimi response timed out. Retry or adjust KIMI_TIMEOUT.'
 if isinstance(reason,socket.gaierror):return 'Kimi域名解析失败，请检查DNS或代理设置。 / Kimi DNS lookup failed; check DNS or proxy settings.'
 if isinstance(reason,ConnectionRefusedError):return 'Kimi连接被拒绝，请检查代理地址和服务状态。 / Kimi connection refused; check proxy and service status.'
 return '无法连接Kimi服务，请检查本机代理、API地址及服务状态。 / Cannot reach Kimi; check the local proxy, API URL and service status.'


def request_json(req,opener):
 """Retry rejected rate-limited requests only; never retry uncertain network failures."""
 import json,time,io
 from urllib.error import HTTPError
 maximum=min(2,max(0,int(os.getenv('KIMI_MAX_RETRIES','2'))))
 for attempt in range(maximum+1):
  job=getattr(CONTROL,'job',None)
  timeout=float(os.getenv('KIMI_TIMEOUT','45'))
  if job:
   import feedback_progress
   feedback_progress.check(job);timeout=min(timeout,max(1,job['deadline']-time.time()))
  try:
   with opener(req,timeout=timeout,context=tls_context()) as response:result=json.load(response)
   result['_transport_retries']=attempt
   return result
  except HTTPError as exc:
   try:raw=exc.read();error=json.loads(raw).get('error',{})
   except Exception:raw=b'';error={}
   # Do not expose upstream text, which could contain user material.
   descriptor=str(error.get('type',''))+' '+str(error.get('code',''))+' '+str(error.get('message','')) if isinstance(error,dict) else ''
   quota=any(word in descriptor.lower() for word in ['insufficient_quota','insufficient balance','credit','balance not enough','exceeded your current quota'])
   exc.kimi_reason='quota' if quota else 'rate_limit' if exc.code==429 else 'http_error'
   exc.kimi_error_type=str(error.get('type',''))[:100] if isinstance(error,dict) else ''
   exc.fp=io.BytesIO(raw)
   if exc.code!=429 or quota or attempt==maximum:raise
   try:delay=float(exc.headers.get('Retry-After',''))
   except (TypeError,ValueError,AttributeError):delay=20*(attempt+1)
   if delay>60:raise
   delay=max(20*(attempt+1),delay)
   if job:
    import feedback_progress
    feedback_progress.update(job,'retrying',seconds=round(delay))
    job['cancel'].wait(min(delay,max(0,job['deadline']-time.time())))
    feedback_progress.check(job)
   else:time.sleep(delay)
