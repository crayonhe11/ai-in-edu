"""Bounded progress state and cancellation tests, without external calls."""
import time,unittest
from unittest.mock import patch,Mock
import feedback_progress as progress
import kimi_transport
class ProgressTests(unittest.TestCase):
 def test_roles_and_review_are_visible_without_exposing_outputs(self):
  j=progress.start('local','job-a');progress.update(j,'role_started',role='mentor');progress.update(j,'role_complete',role='mentor');progress.update(j,'review_started')
  d=progress.snapshot('local');self.assertEqual(d['roles']['mentor'],'received');self.assertEqual(d['phase'],'review_started');self.assertNotIn('cancel',d);self.assertNotIn('content',d)
 def test_cancel_interrupts_before_next_api_request(self):
  j=progress.start('cancel-test');progress.cancel('cancel-test',j['job_id']);kimi_transport.CONTROL.job=j;self.addCleanup(setattr,kimi_transport.CONTROL,'job',None);opener=Mock()
  with self.assertRaisesRegex(RuntimeError,'取消'):kimi_transport.request_json(object(),opener)
  opener.assert_not_called()
 def test_expired_deadline_prevents_api_request(self):
  j=progress.start('expired');j['deadline']=time.time()-1;kimi_transport.CONTROL.job=j;self.addCleanup(setattr,kimi_transport.CONTROL,'job',None);opener=Mock()
  with self.assertRaisesRegex(RuntimeError,'180'):kimi_transport.request_json(object(),opener)
  opener.assert_not_called()
 def test_finished_job_has_clear_terminal_status(self):
  j=progress.start('finish');progress.finish(j,'failed','明确错误');self.assertEqual(progress.snapshot('finish')['error'],'明确错误');self.assertEqual(progress.snapshot('finish')['status'],'failed')
 def test_old_cancel_does_not_cancel_a_new_job(self):
  progress.start('same-student','old-job');current=progress.start('same-student','new-job');progress.cancel('same-student','old-job');self.assertFalse(current['cancel'].is_set())
 def test_cancel_before_request_arrives_prevents_generation(self):
  progress.cancel('early','not-yet-started');current=progress.start('early','not-yet-started');self.assertTrue(current['cancel'].is_set())
