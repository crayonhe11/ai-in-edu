"""Authenticated local experiment attachments; no model upload or measurement extraction."""
import json,re,secrets,shutil
from pathlib import Path
from urllib.parse import parse_qs,urlsplit
MAX_FILE=50*1024*1024
MAX_TOTAL=200*1024*1024

def root(db):return Path(db).resolve().parent/'experiment_media'
def folder(db,sid):
 if not re.fullmatch(r'[a-f0-9]{24}',sid):raise ValueError('Invalid session ID')
 return root(db)/sid

def detect(data):
 if data.startswith(b'\x89PNG\r\n\x1a\n'):return 'image/png'
 if data.startswith(b'\xff\xd8\xff'):return 'image/jpeg'
 if data[:4]==b'RIFF' and data[8:12]==b'WEBP':return 'image/webp'
 if data.startswith(b'\x1aE\xdf\xa3'):return 'video/webm'
 if len(data)>12 and data[4:8]==b'ftyp':return 'video/quicktime' if data[8:12]==b'qt  ' else 'video/mp4'
 raise ValueError('仅支持 JPG、PNG、WebP、MP4、WebM、MOV / Unsupported media format')

def route(h,path,server):
 # This route runs before the small JSON body parser. Authenticate before reading bytes.
 teacher=path[:2]==['api','teacher']
 offset=4 if teacher else 3
 if teacher:
  if len(path)<5 or path[2]!='sessions' or path[4]!='attachments':return False
  server.teacher_auth.require(h.headers.get('Authorization','').removeprefix('Bearer '))
  sid=path[3]
  with server.connect() as c:row=c.execute('SELECT data FROM sessions WHERE id=?',(sid,)).fetchone()
  if not row:raise PermissionError('Session unavailable')
  state=json.loads(row[0])
 else:
  if len(path)<4 or path[:2]!=['api','sessions'] or path[3]!='attachments':return False
  sid=path[2];state=server.load(sid,h.headers.get('Authorization','').removeprefix('Bearer '))
 items=state.setdefault('attachments',[]);tail=path[offset+1:]
 if h.command=='GET' and len(tail)==1:
  item=next((x for x in items if x['id']==tail[0]),None)
  if not item:raise ValueError('附件不存在 / Attachment not found')
  target=folder(server.DB,sid)/item['id']
  if not target.is_file():raise ValueError('附件文件缺失 / Attachment file missing')
  data=target.read_bytes();h.send_response(200);h.send_header('Content-Type',item['mime']);h.send_header('Content-Length',str(len(data)));h.send_header('Cache-Control','no-store');h.send_header('X-Content-Type-Options','nosniff');h.end_headers();h.wfile.write(data);return True
 if teacher:raise PermissionError('教师仅可查看附件 / Teacher attachments are read-only')
 with server.LOCK:
  if sid in server.BUSY:h.send(409,{'error':'会话正在处理，请重试 / Session busy'});return True
  server.BUSY.add(sid)
 try:
  state=server.load(sid,h.headers.get('Authorization','').removeprefix('Bearer '));items=state.setdefault('attachments',[])
  if h.command=='POST' and not tail:
   n=int(h.headers.get('Content-Length','0'))
   if not 0<n<=MAX_FILE:h.send(413,{'error':'每个附件最大50MB / Maximum 50MB per attachment'});return True
   if len(items)>=20 or sum(x['size'] for x in items)+n>MAX_TOTAL:raise ValueError('最多20个附件、合计200MB / Limit: 20 attachments, 200MB total')
   q=parse_qs(urlsplit(h.path).query);name=Path(q.get('name',['experiment'])[0].replace('\\','/')).name[:180]
   caption=q.get('caption',[''])[0].strip()
   if not name or len(caption)>1000:raise ValueError('附件名称或说明过长 / Invalid name or caption')
   data=h.rfile.read(n)
   if len(data)!=n:raise ValueError('上传未完成 / Incomplete upload')
   mime=detect(data)
   if mime.startswith('image/') and n>10*1024*1024:raise ValueError('照片最大10MB / Images must be at most 10MB')
   item={'id':secrets.token_hex(16),'name':name,'mime':mime,'size':n,'caption':caption,'uploaded_at':server.research.stamp(),'source':'student_uploaded_unverified','notice':'学生上传，来源与内容未经核验；不自动提取测量值 / Student upload, unverified; no automatic measurement extraction'}
   dest=folder(server.DB,sid);dest.mkdir(parents=True,exist_ok=True);target=dest/item['id'];target.write_bytes(data)
   try:
    items.append(item);server.research.record(state,'attachment_added',{'attachment':item});server.save(sid,state)
   except Exception:target.unlink(missing_ok=True);raise
  elif h.command=='DELETE' and len(tail)==1:
   item=next((x for x in items if x['id']==tail[0]),None)
   if not item:raise ValueError('附件不存在 / Attachment not found')
   state['attachments']=[x for x in items if x['id']!=item['id']];server.research.record(state,'attachment_deleted',{'attachment':item});server.save(sid,state);(folder(server.DB,sid)/item['id']).unlink(missing_ok=True)
  else:h.send(404,{'error':'接口不存在 / Endpoint not found'});return True
  h.send(200,server.view(sid,state));return True
 finally:
  with server.LOCK:server.BUSY.discard(sid)

def cleanup(db,sid):shutil.rmtree(folder(db,sid),ignore_errors=True)
