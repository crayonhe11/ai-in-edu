"""Offline tests for authentic feedback and legacy canned-response recovery."""
import io,json,unittest,os
from unittest.mock import patch
from urllib.error import URLError,HTTPError
import server as app
import research,learning
from domain import empty_state,protect_core_output

class FeedbackTests(unittest.TestCase):
 def setUp(self):
  self.env=patch.dict(os.environ,{"KIMI_MAX_RETRIES":"0"});self.env.start();self.addCleanup(self.env.stop)
 def state(self):
  s=research.normalize(empty_state());s['stage']=2
  s['notebook'].update(independent='学生写的变量条件',dependent='学生写的测量指标',controls='学生写的控制条件',procedure='学生写的实验步骤')
  learning.submit_draft(s,{})
  return s
 def response(self,value):return io.BytesIO(json.dumps({'choices':[{'message':{'content':value}}]}).encode())
 def test_safe_punctuation_preserves_real_content(self):
  s=self.state();items=[{'content':'引用学生的变量条件，提出一个测量追问。'}]
  with patch.object(app,'MODE','live'),patch.object(app,'urlopen',return_value=self.response('SAFE.')):
   result,audit=app.review_outputs(s,items)
  self.assertEqual(result,items);self.assertFalse(audit['replaced']);self.assertIn('测量追问',result[0]['content'])
 def test_markdown_fenced_json_safe_is_recognized(self):
  s=self.state();items=[{'content':'针对学生变量条件的追问。'}]
  with patch.object(app,'MODE','live'),patch.object(app,'urlopen',return_value=self.response('```json\n{"verdict":"SAFE","reason":"Only feedback questions."}\n```')):
   result,audit=app.review_outputs(s,items)
  self.assertEqual(result,items);self.assertFalse(audit['replaced'])
 def test_review_failure_never_turns_into_live_canned_feedback(self):
  s=self.state()
  for exc in [URLError('local mock disconnected'),HTTPError('http://local',429,'limit',{},None)]:
   with patch.object(app,'MODE','live'),patch.object(app,'KEY','fake'),patch.object(app,'call_kimi',side_effect=lambda role,*a,**kw:(role+' asks about the submitted variable.',{})),patch.object(app,'urlopen',side_effect=exc):
    with self.assertRaises(RuntimeError):app.round_agents(s,'请检查我的稿件。')
   self.assertEqual(s['messages'],[]);self.assertEqual(s['rounds'],0);self.assertIsNone(s['pending_reflection'])
 def test_inconclusive_or_revise_never_becomes_success(self):
  for value in ['REVISE','', 'I am not sure']:
   with patch.object(app,'MODE','live'),patch.object(app,'urlopen',return_value=self.response(value)):
    with self.assertRaises(RuntimeError):app.review_outputs(self.state(),[{'content':'test'}])
 def test_three_identical_replies_are_not_valid_feedback(self):
  s=self.state()
  with patch.object(app,'MODE','live'),patch.object(app,'KEY','fake'),patch.object(app,'call_kimi',return_value=('同一句无关的提示',{})):
   with self.assertRaisesRegex(RuntimeError,'相同'):app.round_agents(s,'请检查我的稿件。')
  self.assertEqual(s['messages'],[])
 def test_legacy_canned_gate_is_removed_without_deleting_history(self):
  s=self.state();did=s['drafts'][0]['id']
  s['messages']=[{'id':str(i),'role':r,'mode':'live','draft_id':did,'content':'我可以帮你检查思路，但核心内容需要你完成。'} for i,r in enumerate(['mentor','skeptic','peer'])]
  research.gate(s,[{'message_id':m['id'],'content':m['content'],'origin':'live','role':m['role']} for m in s['messages']],'agent_round')
  s=research.normalize(s)
  self.assertEqual(len(s['messages']),3);self.assertTrue(all(m['mode']=='system_fallback' for m in s['messages']));self.assertIsNone(s['pending_reflection'])
  with self.assertRaises(ValueError):learning.mark_feedback_read(s,{'draft_id':did})
 def test_questions_and_numbered_hints_are_not_complete_answers(self):
  for text in ['你的假设是否可以被实验证伪？','1. 你准备改变什么？\n2. 怎样测量？\n3. 哪些条件保持一致？']:
   self.assertEqual(protect_core_output(text),text)
  self.assertIn('your own',protect_core_output('Hypothesis: Made-up full answer.','en'))

class RetryTests(unittest.TestCase):
 def error(self,code,kind,message=''):
  return HTTPError('http://local',code,'mock',{'Retry-After':'1'},io.BytesIO(json.dumps({'error':{'type':kind,'message':message}}).encode()))
 def test_rate_limit_retry_preserves_response(self):
  import kimi_transport
  from unittest.mock import Mock
  opener=Mock(side_effect=[self.error(429,'rate_limit_reached'),io.BytesIO(b'{"choices": [], "usage": {}}')])
  with patch.dict(os.environ,{'KIMI_MAX_RETRIES':'2'}),patch('time.sleep') as sleep,patch.object(kimi_transport,'tls_context',return_value=None):
   result=kimi_transport.request_json(object(),opener)
  self.assertEqual(result['_transport_retries'],1);self.assertEqual(opener.call_count,2);sleep.assert_called_once_with(20)
 def test_quota_and_non_rate_errors_are_not_retried(self):
  import kimi_transport
  from unittest.mock import Mock
  for code,kind in [(429,'insufficient_quota'),(401,'invalid_key'),(503,'service_unavailable')]:
   opener=Mock(side_effect=self.error(code,kind))
   with patch.dict(os.environ,{'KIMI_MAX_RETRIES':'2'}),patch('time.sleep') as sleep,patch.object(kimi_transport,'tls_context',return_value=None):
    with self.assertRaises(HTTPError):kimi_transport.request_json(object(),opener)
   self.assertEqual(opener.call_count,1);sleep.assert_not_called()
 def test_rate_limit_has_bounded_attempts(self):
  import kimi_transport
  from unittest.mock import Mock
  opener=Mock(side_effect=[self.error(429,'rate_limit_reached') for _ in range(3)])
  with patch.dict(os.environ,{'KIMI_MAX_RETRIES':'2'}),patch('time.sleep') as sleep,patch.object(kimi_transport,'tls_context',return_value=None):
   with self.assertRaises(HTTPError):kimi_transport.request_json(object(),opener)
  self.assertEqual(opener.call_count,3);self.assertEqual(sleep.call_count,2)
