"""Local prototype teacher credentials, separate from student capabilities."""
import hashlib,os,secrets,time,threading
from pathlib import Path
ROOT=Path(__file__).resolve().parent
KEY_FILE=ROOT/'.teacher_access'
TOKENS={};ATTEMPTS={};LOCK=threading.Lock()
def ensure_key():
 if os.getenv('TEACHER_PASSWORD'):return
 try:
  fd=os.open(KEY_FILE,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 except FileExistsError:return
 with os.fdopen(fd,'w') as f:f.write(secrets.token_urlsafe(18)+'\n')

def login(password,ip):
 now=time.time()
 with LOCK:
  ATTEMPTS[ip]=[x for x in ATTEMPTS.get(ip,[]) if now-x<300]
  if len(ATTEMPTS[ip])>=8:raise PermissionError('教师登录尝试过多，请5分钟后重试 / Too many attempts. Retry in 5 minutes')
  ensure_key();expected=os.getenv('TEACHER_PASSWORD') or KEY_FILE.read_text().strip()
  if not isinstance(password,str) or not secrets.compare_digest(password.encode(),expected.encode()):
   ATTEMPTS[ip].append(now);raise PermissionError('教师口令无效 / Invalid teacher password')
  ATTEMPTS.pop(ip,None)
  token=secrets.token_urlsafe(32);TOKENS[hashlib.sha256(token.encode()).hexdigest()]=now+8*3600;return token

def require(token):
 hashed=hashlib.sha256(token.encode()).hexdigest()
 with LOCK:
  expiry=TOKENS.get(hashed,0)
  if expiry<time.time():TOKENS.pop(hashed,None);raise PermissionError('教师登录已失效，请重新登录 / Teacher authentication required')

def logout(token):
 with LOCK:TOKENS.pop(hashlib.sha256(token.encode()).hexdigest(),None)
