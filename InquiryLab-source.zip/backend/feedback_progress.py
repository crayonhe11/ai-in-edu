"""Session-private progress for an in-flight feedback request."""
import time,threading,secrets
LOCK=threading.Lock();JOBS={};CANCELLED=set();LIMIT=180

def start(sid,job_id=None):
 now=time.time()
 with LOCK:
  for key in list(JOBS):
   if JOBS[key]['status']!='running' and now-JOBS[key]['started_at']>3600:del JOBS[key]
  j={'job_id':job_id if isinstance(job_id,str) and len(job_id)<=100 else secrets.token_hex(12),'status':'running','phase':'starting','roles':{},'started_at':now,'deadline':now+LIMIT,'retry_seconds':0,'error':'','cancel':threading.Event()};JOBS[sid]=j
  if (sid,j['job_id']) in CANCELLED:j['cancel'].set();CANCELLED.discard((sid,j['job_id']))
 return j

def snapshot(sid):
 with LOCK:return {k:(dict(v) if k=='roles' else v) for k,v in JOBS.get(sid,{'status':'idle'}).items() if k!='cancel'}

def check(job):
 if job['cancel'].is_set():raise RuntimeError('本轮反馈已取消；已保存的初稿不变。 / Feedback cancelled; your submitted draft is preserved.')
 if time.time()>=job['deadline']:raise RuntimeError('本轮反馈已超过180秒，已停止继续请求。请稍后重试。 / Feedback exceeded 180 seconds; retry later.')

def update(job,kind,**data):
 check(job)
 with LOCK:
  job['phase']=kind
  if kind=='role_started':job['roles'][data['role']]='running'
  elif kind=='role_complete':job['roles'][data['role']]='received'
  elif kind=='retrying':job['retry_seconds']=data['seconds']

def finish(job,status,error=''):
 with LOCK:job['status']=status;job['phase']=status;job['error']=error

def cancel(sid,job_id):
 if not isinstance(job_id,str) or not job_id or len(job_id)>100:raise ValueError('缺少当前任务编号 / Current job ID required')
 with LOCK:
  job=JOBS.get(sid)
  if job and job['job_id']==job_id and job['status']=='running':job['cancel'].set()
  elif not job or job['job_id']!=job_id:
   if len(CANCELLED)>=2048:CANCELLED.clear()
   CANCELLED.add((sid,job_id))
