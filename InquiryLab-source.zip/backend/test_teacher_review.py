import unittest,json,copy
from types import SimpleNamespace
from unittest.mock import patch
from test_backend import Tests
import server as app,learning,research,teacher_review
from domain import empty_state
class TeacherReviewAPI(Tests):
 def test_grading_persists_and_keeps_guidance(self):
  p,t=self.new();teacher=self.teacher()
  self.api('teacher/'+p,'PATCH',{'note':'请补充温度记录','paused':True},teacher)
  assessment={'scores':{'question':20,'controls':18,'evidence':16,'limitations':19},'score_reasons':{'evidence':'需要更多独立重复'},'feedback':'请结合异常备注解释证据。','rubric':{}}
  code,d=self.api('teacher/'+p,'PATCH',{'assessment':assessment},teacher);self.assertEqual(code,200);self.assertEqual(d['state']['teacher_assessment']['total'],73);self.assertEqual(d['state']['teacher'],{'note':'请补充温度记录','paused':True})
  self.assertEqual(self.api('teacher/'+p,token=teacher)[1]['state']['teacher_assessment']['total'],73)
  for scores in ({'question':20},{'question':26,'controls':0,'evidence':0,'limitations':0},{'question':True,'controls':0,'evidence':0,'limitations':0}):
   self.assertEqual(self.api('teacher/'+p,'PATCH',{'assessment':{'scores':scores}},teacher)[0],400)
  self.assertEqual(self.api('teacher/'+p,token=teacher)[1]['state']['teacher_assessment']['total'],73)
 def test_feedback_auth_source_and_staleness(self):
  p,t=self.new();teacher=self.teacher()
  self.assertEqual(self.api('teacher/'+p+'/feedback','POST',{'language':'zh'},t)[0],403)
  code,d=self.api('teacher/'+p+'/feedback','POST',{'language':'zh'},teacher);self.assertEqual(code,200);f=d['teacher_feedback'];self.assertEqual(f['source'],'rule_based_demo');self.assertFalse(f['stale']);self.assertEqual(len(f['stages']),5);self.assertIsNone(d['state']['teacher_assessment'].get('total'))
  oldid=f['id'];self.api(p+'/notebook','PATCH',{'notebook':{'question':'新的科学问题：温度如何影响发芽率？'}},t)
  d=self.api('teacher/'+p,token=teacher)[1];self.assertTrue(d['teacher_feedback']['stale']);self.assertEqual(d['teacher_feedback']['id'],oldid)
 def test_feedback_has_valid_references_and_no_numeric_grade(self):
  p,t=self.new();self.api(p+'/notebook','PATCH',{'notebook':{'question':'水量如何影响绿豆发芽率？'}},t);teacher=self.teacher()
  with patch.object(app,'call_kimi',side_effect=AssertionError('Rule mode must not call Kimi')):
   code,d=self.api('teacher/'+p+'/feedback','POST',{'language':'en'},teacher)
  self.assertEqual(code,200);f=d['teacher_feedback'];refs=teacher_review.evidence(d['state'])
  for item in f['strengths']+f['attention']:
   for ref in item['evidence_ids']:self.assertIn(ref,refs)
  self.assertNotIn('scores',f);self.assertNotIn('grade',f)

class TeacherLiveReview(unittest.TestCase):
 def test_real_model_path_and_unknown_reference_rejected(self):
  s=research.normalize(empty_state());s['notebook']['question']='How does water affect germination?'
  answer={'summary':'A question is recorded; the rest requires evidence.','strengths':[{'text':'The question identifies water.','evidence_ids':['notebook:question']}],'attention':[],'questions':['How will you measure germination?']}
  transport=SimpleNamespace(request_json=lambda req,opener:{'choices':[{'message':{'content':json.dumps(answer)}}]})
  server=SimpleNamespace(effective_mode=lambda s:'live',KEY='test-key-only',MODEL='kimi-k2.6',BASE='https://example.invalid',kimi_transport=transport,urlopen=None)
  f=teacher_review.generate(s,'en',server);self.assertEqual(f['source'],'kimi');self.assertFalse(teacher_review.current(s)['stale'])
  old=copy.deepcopy(s['teacher_process_feedback']);answer['strengths'][0]['evidence_ids']=['measurement:invented']
  with self.assertRaises(RuntimeError):teacher_review.generate(s,'en',server)
  self.assertEqual(s['teacher_process_feedback'],old)
if __name__=='__main__':unittest.main()
