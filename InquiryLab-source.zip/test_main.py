"""Exercise the real main() launcher with an occupied preferred port."""
import os,re,socket,subprocess,sys,tempfile,unittest,json
from pathlib import Path
from urllib.request import urlopen,Request
class LauncherTest(unittest.TestCase):
 def test_occupied_port_and_same_origin_api(self):
  with tempfile.TemporaryDirectory() as tmp,socket.socket() as occupied:
   occupied.bind(('127.0.0.1',0));occupied.listen();port=occupied.getsockname()[1]
   proc=subprocess.Popen([sys.executable,str(Path(__file__).parent/'main.py'),'--port',str(port),'--no-browser'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env={**os.environ,'DB_PATH':tmp+'/test.sqlite3','APP_MODE':'demo'})
   try:
    lines=[];url=None
    for _ in range(8):
     line=proc.stdout.readline();lines.append(line)
     if re.fullmatch(r'http://127\.0\.0\.1:\d+\n',line):url=line.strip();break
    self.assertIsNotNone(url,''.join(lines));self.assertNotEqual(url,f'http://127.0.0.1:{port}')
    with urlopen(url+'/api/health',timeout=4) as r:self.assertEqual(json.load(r)['mode'],'demo')
    with urlopen(url+'/runtime-config.js',timeout=4) as r:self.assertIn('location.origin',r.read().decode())
    with urlopen(url,timeout=4) as r:self.assertIn('id="language"',r.read().decode())
    req=Request(url+'/api/sessions',data=b'{}',headers={'Content-Type':'application/json','Origin':url})
    with urlopen(req,timeout=4) as r:state=json.load(r)
    self.assertIn('token',state)
    req=Request(url+'/api/sessions/'+state['id']+'/chat',data=json.dumps({'message':'How can I measure this?','language':'bi'}).encode(),headers={'Content-Type':'application/json','Origin':url,'Authorization':'Bearer '+state['token']})
    with urlopen(req,timeout=4) as r:result=json.load(r)
    self.assertIn('English:',result['state']['messages'][-1]['content'])
   finally:
    proc.terminate()
    try:proc.communicate(timeout=5)
    except subprocess.TimeoutExpired:proc.kill();proc.communicate()
if __name__=='__main__':unittest.main(verbosity=2)
